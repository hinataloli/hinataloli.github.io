// client.js
document.addEventListener('DOMContentLoaded', () => {
    // State
    let socket, currentRoomId = null, roomsData = [], pageCounters = {}, hasMoreMessages = {}, isLoading = false, typingTimer;
    const TYPING_TIMER_LENGTH = 1500;
    let friendRequestCount = 0;
    let unreadNotifications = 0;

    // Feed & Search State
    let currentView = 'feed';
    let feedPageCounter = 0;
    let hasMorePosts = true;
    let isFeedLoading = false;
    let activePostIdForComments = null;
    let commentPageCounter = 0;
    let hasMoreComments = true;
    let isCommentsLoading = false;
    let currentSearchQuery = '';
    let searchPostPageCounter = 0;
    let hasMoreSearchPosts = true;
    let isSearchLoading = false;

    // Chat State
    let replyingToMessage = null; // Trạng thái tin nhắn đang trả lời
    let onlineFriendIds = new Set(); // Theo dõi ID người dùng online

    // DOM Elements Helper
    const D = (id) => document.getElementById(id);

    // DOM Elements
    const authContainer = D('auth-container'), appWrapper = D('app-wrapper'),
        loginForm = D('login-form'), registerForm = D('register-form'),
        publicRoomList = D('public-room-list'), privateRoomList = D('private-room-list'),
        chatPlaceholder = D('chat-placeholder'), chatContainer = D('chat-container'),
        messagesContainer = D('messages-container'), messageList = D('messages'), messageForm = D('form'),
        messageInput = D('input-text'), logoutBtn = D('logout-btn'),
        loadMoreBtn = D('load-more-btn'), userProfile = D('user-profile'), headerAvatar = D('header-avatar'),
        avatarUploadForm = D('avatar-upload-form'), avatarInput = D('avatar-input'),
        createRoomBtn = D('create-room-btn'), createRoomModal = D('create-room-modal'),
        submitCreateRoomBtn = D('submit-create-room'), publicRoomOption = D('public-room-option'),
        inviteUserBtn = D('invite-user-btn'), inviteUserModal = D('invite-user-modal'), searchUserBtn = D('search-user-btn'),
        getInviteLinkBtn = D('get-invite-link-btn'), inviteLinkModal = D('invite-link-modal'),
        copyInviteLinkBtn = D('copy-invite-link-btn'), inviteLinkText = D('invite-link-text'),
        chatRoomName = D('chat-room-name'), avatarPreview = D('avatar-preview'), regAvatarInput = D('reg-avatar-input'),
        goToRegisterLink = D('go-to-register'), goToLoginLink = D('go-to-login'),
        headerDisplayName = D('header-display-name'), headerUsername = D('header-username'),
        invitationsContainer = D('invitations-container'), invitationList = D('invitation-list'),
        manageRoomBtn = D('manage-room-btn'), manageRoomModal = D('manage-room-modal'),
        pendingList = D('pending-list'), membersList = D('members-list'),
        leaveRoomBtn = D('leave-room-btn'),
        confirmModal = D('confirm-modal'), confirmModalTitle = D('confirm-modal-title'),
        confirmModalText = D('confirm-modal-text'), confirmModalYesBtn = D('confirm-modal-yes-btn'),
        confirmModalNoBtn = D('confirm-modal-no-btn'),
        typingIndicator = D('typing-indicator'),
        sidebar = D('sidebar'), sidebarOverlay = D('sidebar-overlay'),
        chatHeaderActions = D('chat-view').querySelector('.chat-header-actions'),
        inviteSearchInput = D('invite-username-search'),
        inviteSearchResults = D('invite-search-results'),
        inviteUserMessage = D('invite-user-message'),
        attachImageBtn = D('attach-image-btn'),
        chatImageInput = D('chat-image-input'),
        imageViewerModal = D('image-viewer-modal'),
        imageViewerImg = D('image-viewer-img'),
        imageViewerInfo = D('image-viewer-info'),
        imageViewerSender = D('image-viewer-sender'),
        imageViewerTime = D('image-viewer-time'),
        imageViewerDeleteBtn = D('image-viewer-delete-btn'),
        messageContextMenu = D('message-context-menu'),
        profileViewModal = D('profile-view-modal'),
        profileEditModal = D('profile-edit-modal'),
        profileAvatar = D('profile-avatar'),
        profileDisplayName = D('profile-display-name'),
        profileUsername = D('profile-username'),
        profileJoinDate = D('profile-join-date'),
        profileModalFooter = D('profile-modal-footer'),
        profileEditForm = D('profile-edit-form'),
        editDisplayNameInput = D('edit-display-name-input'),
        editNewPasswordInput = D('edit-new-password-input'),
        profileEditMessage = D('profile-edit-message'),
        saveProfileBtn = D('save-profile-btn'),
        navFeedBtn = D('nav-feed-btn'),
        navChatBtn = D('nav-chat-btn'),
        navFriendsBtn = D('nav-friends-btn'),
        chatSidebarContent = D('chat-sidebar-content'),
        sidebarFooter = D('sidebar-footer'),
        feedView = D('feed-view'),
        chatView = D('chat-view'),
        searchView = D('search-view'),
        friendsView = D('friends-view'),
        friendRequestBadge = D('friend-request-badge'),
        friendRequestsSection = D('friend-requests-section'),
        friendRequestsList = D('friend-requests-list'),
        myFriendsList = D('my-friends-list'),
        postList = D('post-list'),
        createPostForm = D('create-post-form'),
        createPostTextarea = D('create-post-textarea'),
        createPostAvatar = D('create-post-avatar'),
        submitPostBtn = D('submit-post-btn'),
        postImageInput = D('post-image-input'),
        postImagePreview = D('post-image-preview'),
        postPrivacySelect = D('post-privacy-select'),
        feedContent = feedView.querySelector('.feed-content'),
        loadMorePostsBtn = D('load-more-posts-btn'),
        commentsModal = D('comments-modal'),
        commentsList = D('comments-list'),
        commentForm = D('comment-form'),
        commentInput = D('comment-input'),
        searchForm = D('search-form'),
        searchInput = D('search-input'),
        searchQueryDisplay = D('search-query-display'),
        searchUserResults = D('search-user-results'),
        searchPostResults = D('search-post-results'),
        loadMoreSearchPostsBtn = D('load-more-search-posts-btn'),
        notificationBellBtn = D('notification-bell-btn'),
        notificationBadge = D('notification-badge'),
        notificationPanel = D('notification-panel'),
        notificationList = D('notification-list'),
        markAllReadBtn = D('mark-all-read-btn'),
        editPostModal = D('edit-post-modal'),
        editPostForm = D('edit-post-form'),
        messageRequestsContainer = D('message-requests-container'),
        messageRequestList = D('message-request-list'),
        blockUserBtn = D('block-user-btn'),
        replyPreviewContainer = D('reply-preview-container'),
        closeReplyPreviewBtn = D('close-reply-preview'),
        replyPreviewSender = D('reply-preview-sender'),
        replyPreviewText = D('reply-preview-text');

    // --- UTILS ---
    const apiRequest = async (endpoint, options = {}) => {
        const token = localStorage.getItem('token');
        const headers = options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;
        const res = await fetch(endpoint, { ...options, headers });
        if (res.status === 204) return null;
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'An error occurred');
        return data;
    };

    const showToast = (text, type = 'info') => {
        const style = getComputedStyle(document.documentElement);
        const colors = {
            info: style.getPropertyValue('--accent-color').trim(),
            success: style.getPropertyValue('--success-color').trim(),
            warning: '#ffc107',
            error: style.getPropertyValue('--danger-color').trim(),
        };
        Toastify({ text, duration: 3000, close: true, gravity: "top", position: "right", stopOnFocus: true, style: { background: colors[type] || colors.info } }).showToast();
    };

    const switchView = (viewName) => {
        currentView = viewName;
        ['feed', 'chat', 'search', 'friends'].forEach(v => D(`${v}-view`).classList.toggle('active', v === viewName));
        ['feed', 'chat', 'friends'].forEach(v => D(`nav-${v}-btn`).classList.toggle('active', v === viewName));
        chatSidebarContent.classList.toggle('active', viewName === 'chat');
        // FIX: Đảm bảo sidebar footer luôn được hiển thị trong tất cả các view trừ khi ở chế độ Chat cần hiển thị nút Leave Room
        sidebarFooter.classList.toggle('active', viewName === 'chat');
        leaveRoomBtn.style.display = 'none'; 
        
        if (viewName === 'feed') loadPosts(true);
        if (viewName === 'friends') { loadFriendRequests(); loadFriendsList(); }
        
        D(`nav-search-btn`)?.classList.remove('active');
    };

    const switchForm = (form) => { D('login-form-container').style.display = form === 'login' ? 'block' : 'none'; D('register-form-container').style.display = form === 'register' ? 'block' : 'none'; D('auth-message').textContent = ''; D('auth-message-reg').textContent = ''; };
    const showAuthMessage = (message, form = 'login', type = 'error') => { const el = D(form === 'login' ? 'auth-message' : 'auth-message-reg'); el.textContent = message; el.style.color = type === 'error' ? 'var(--danger-color)' : 'var(--success-color)'; };
    const openModal = (id) => D(id).classList.add('active');
    const closeModal = (id) => D(id).classList.remove('active');
    
    const showConfirmation = (title, text, options = {}) => new Promise((resolve) => {
        confirmModalTitle.textContent = title;
        confirmModalText.innerHTML = text;
        const iconContainer = confirmModal.querySelector('.confirm-dialog-icon');
        iconContainer.className = 'confirm-dialog-icon';
        if (options.danger) {
            iconContainer.classList.add('danger');
            confirmModalYesBtn.classList.add('btn-danger');
        } else {
            confirmModalYesBtn.classList.remove('btn-danger');
        }
        openModal('confirm-modal');
        const onYes = () => { closeModal('confirm-modal'); confirmModalYesBtn.removeEventListener('click', onYes); confirmModalNoBtn.removeEventListener('click', onNo); resolve(true); };
        const onNo = () => { closeModal('confirm-modal'); confirmModalYesBtn.removeEventListener('click', onYes); confirmModalNoBtn.removeEventListener('click', onNo); resolve(false); };
        confirmModalYesBtn.addEventListener('click', onYes);
        confirmModalNoBtn.addEventListener('click', onNo);
    });
    
    const scrollToBottomIfNeeded = (force = false) => {
        const scrollBuffer = 150; 
        const isScrolledNearBottom = messagesContainer.scrollHeight - messagesContainer.clientHeight <= messagesContainer.scrollTop + scrollBuffer;
        if (force || isScrolledNearBottom) {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    };

    const addOnlineIndicator = (element, userId) => {
        // Hàm này không cần thay đổi logic, chỉ cần đảm bảo nó hoạt động với cấu trúc DOM mới
        if (!element || element.querySelector('.online-indicator')) return;
        const isOnline = onlineFriendIds.has(parseInt(userId));
        if (isOnline) {
            const indicator = document.createElement('span');
            indicator.className = 'online-indicator';
            
            // Tìm container chứa avatar để thêm indicator vào đúng vị trí tương đối
            const avatarContainer = element.closest('.profile-header') || 
                                    element.closest('#user-profile') ||
                                    element.closest('.friend-item div[style="position: relative;"]') ||
                                    element.closest('.search-user-item div[style="position: relative;"]');
                                    
            // Logic cũ (avatarContainer là element)
            if (element.tagName === 'IMG') {
                 element.parentElement.appendChild(indicator);
            } else if (avatarContainer) {
                avatarContainer.querySelector('.online-indicator')?.remove(); // Xóa cái cũ nếu có
                avatarContainer.appendChild(indicator);
            } else {
                // Trường hợp default (ví dụ: avatar trong tin nhắn)
                element.appendChild(indicator);
            }
        }
    };
    
    const openProfileModal = async (username) => {
        try {
            const userData = await apiRequest(`/api/users/${username}`);
            profileAvatar.src = userData.avatar_url && userData.avatar_url !== 'macdinh.jpg' ? `/api/avatars/${userData.avatar_url}` : '/macdinh.jpg';
            profileDisplayName.textContent = userData.display_name;
            profileUsername.textContent = `@${userData.username}`;
            profileUsername.dataset.userId = userData.id;
            profileJoinDate.textContent = new Date(userData.created_at).toLocaleDateString();
    
            const currentUser = JSON.parse(localStorage.getItem('user'));
            profileModalFooter.innerHTML = '';
            
            // Thêm online indicator vào avatar profile modal
            const avatarContainer = profileAvatar.closest('.profile-header');
            avatarContainer.querySelector('.online-indicator')?.remove();
            
            if (onlineFriendIds.has(userData.id)) {
                const indicator = document.createElement('span');
                indicator.className = 'online-indicator';
                profileAvatar.parentElement.appendChild(indicator);
            }

            if (currentUser && currentUser.username === userData.username) {
                const editBtn = document.createElement('button');
                editBtn.id = 'edit-profile-btn';
                editBtn.textContent = 'Edit Profile';
                profileModalFooter.appendChild(editBtn);
                
                // Xử lý khi mở modal edit
                editBtn.addEventListener('click', () => {
                    const displayNameInput = D('edit-display-name-input');
                    const cooldownMessage = D('display-name-cooldown-message');
                    const sevenDays = 7 * 24 * 60 * 60 * 1000;
                    const lastChanged = new Date(userData.display_name_last_changed).getTime();
                    const now = new Date().getTime();

                    displayNameInput.value = userData.display_name;
                    cooldownMessage.textContent = '';
                    displayNameInput.disabled = false;
                    
                    if (userData.display_name_last_changed && (now - lastChanged < sevenDays) && !currentUser.is_admin) {
                        displayNameInput.disabled = true;
                        const nextChangeDate = new Date(lastChanged + sevenDays);
                        cooldownMessage.textContent = `You can change your name again after ${nextChangeDate.toLocaleDateString()}.`;
                    }

                    D('profile-edit-avatar-preview').src = profileAvatar.src;
                    D('edit-current-password-input').value = '';
                    D('edit-new-password-input').value = '';
                    D('edit-confirm-password-input').value = '';
                    D('allow-stranger-msg-toggle').checked = !!userData.allow_stranger_messages;
                    D('profile-edit-message').textContent = '';
                    
                    // Reset về tab General khi mở modal
                    D('profile-edit-modal').querySelectorAll('.modal-tab-btn').forEach(btn => btn.classList.remove('active'));
                    D('profile-edit-modal').querySelectorAll('.modal-tab-content').forEach(content => content.classList.remove('active'));
                    D('profile-edit-modal').querySelector('[data-tab="general"]').classList.add('active');
                    D('tab-general').classList.add('active');
                    
                    closeModal('profile-view-modal');
                    openModal('profile-edit-modal');
                });
            } else {
                // Lấy trạng thái bạn bè và block
                const statusData = await apiRequest(`/api/friends/status/${username}`);
                updateProfileActions(username, userData.id, statusData); // Gọi hàm mới
            }
            openModal('profile-view-modal');
        } catch (err) {
            showToast(`Could not load profile: ${err.message}`, 'error');
        }
    };
    
    // THAY THẾ: Logic cập nhật nút hành động đã được cải thiện
    const updateProfileActions = (username, userId, statusData) => {
        // Cần đảm bảo statusData là đối tượng, không phải null/undefined
        if (!statusData || typeof statusData !== 'object') {
            statusData = {
                friendship: { status: 'none' },
                isBlocked: false
            };
        }
        
        const { friendship, isBlocked } = statusData;
        profileModalFooter.innerHTML = '';
        
        // 1. Nút Block/Unblock
        const blockBtn = document.createElement('button');
        blockBtn.id = 'block-user-btn';
        blockBtn.dataset.userId = userId;
        blockBtn.dataset.username = username; 
        blockBtn.className = 'friend-btn';
        blockBtn.style.backgroundColor = isBlocked ? 'var(--secondary-text)' : 'var(--danger-color)';
        blockBtn.textContent = isBlocked ? 'Unblock User' : 'Block User';
        blockBtn.dataset.action = isBlocked ? 'unblock' : 'block';
        
        // 2. Nút Message
        const messageBtn = document.createElement('button');
        messageBtn.id = 'message-user-btn';
        messageBtn.textContent = 'Message';
        messageBtn.dataset.userId = userId;
        messageBtn.className = 'friend-btn add';
        
        // 3. Nút Friendship (Add/Friends/Accept)
        const friendBtn = document.createElement('button');
        friendBtn.dataset.username = username;
        friendBtn.dataset.userId = userId;

        if (isBlocked) {
            // Nếu đã bị chặn, chỉ hiển thị nút Unblock
            profileModalFooter.appendChild(blockBtn);
            return;
        }
        
        // Hiển thị nút Message và Friendship
        profileModalFooter.appendChild(messageBtn);
        
        switch (friendship.status) {
            case 'pending':
                if (friendship.isRequester) {
                    friendBtn.textContent = 'Request Sent';
                    friendBtn.className = 'friend-btn pending';
                    friendBtn.onclick = handleCancelRequest;
                } else {
                    friendBtn.textContent = 'Accept Request';
                    friendBtn.className = 'friend-btn accept';
                    friendBtn.onclick = handleAcceptRequest;
                    const declineBtn = document.createElement('button');
                    declineBtn.textContent = 'Decline';
                    declineBtn.className = 'friend-btn decline';
                    declineBtn.dataset.userId = userId;
                    declineBtn.dataset.username = username;
                    declineBtn.onclick = handleDeclineRequest;
                    profileModalFooter.appendChild(declineBtn);
                }
                break;
            case 'accepted':
                friendBtn.textContent = 'Friends';
                friendBtn.className = 'friend-btn friends';
                friendBtn.onclick = handleRemoveFriend;
                break;
            default:
                friendBtn.textContent = 'Add Friend';
                friendBtn.className = 'friend-btn add';
                friendBtn.onclick = handleAddFriend;
                break;
        }
        profileModalFooter.appendChild(friendBtn);
        profileModalFooter.appendChild(blockBtn);
    };

    // --- FEED LOGIC ---
    const timeAgo = (date) => {
        if (!date) return '';
        const seconds = Math.floor((new Date() - new Date(date)) / 1000);
        if (seconds < 5) return "just now";
        let interval = seconds / 31536000; if (interval > 1) return Math.floor(interval) + " years ago";
        interval = seconds / 2592000; if (interval > 1) return Math.floor(interval) + " months ago";
        interval = seconds / 86400; if (interval > 1) return Math.floor(interval) + " days ago";
        interval = seconds / 3600; if (interval > 1) return Math.floor(interval) + " hours ago";
        interval = seconds / 60; if (interval > 1) return Math.floor(interval) + " minutes ago";
        return Math.floor(seconds) + " seconds ago";
    }

    const getPrivacyIcon = (privacy) => {
        switch(privacy) {
            case 'public': return '<i class="fa-solid fa-globe" title="Public"></i>';
            case 'friends': return '<i class="fa-solid fa-user-group" title="Friends"></i>';
            case 'private': return '<i class="fa-solid fa-lock" title="Only me"></i>';
            default: return '';
        }
    };

    const renderPost = (post, container) => {
        const postEl = document.createElement('div');
        postEl.className = 'post-item';
        postEl.dataset.postId = post.id;
        postEl.dataset.username = post.username;
        const avatarSrc = post.avatar_url && post.avatar_url !== 'macdinh.jpg' ? `/api/avatars/${post.avatar_url}` : '/macdinh.jpg';
        const currentUser = JSON.parse(localStorage.getItem('user'));
        let actionsMenuHTML = '';
        if (currentUser && currentUser.username === post.username || currentUser.is_admin) {
            actionsMenuHTML = `
                <div class="post-actions-container">
                    <button class="post-actions-btn" title="Actions"><i class="fa-solid fa-ellipsis"></i></button>
                    <div class="post-actions-menu" style="display: none;">
                        <ul>
                            <li data-action="edit"><i class="fa-solid fa-pencil"></i> Edit Post</li> 
                            <li data-action="delete"><i class="fa-solid fa-trash-can"></i> Delete Post</li>
                        </ul>
                    </div>
                </div>`;
        }
        postEl.innerHTML = `
            <div class="post-header">
                <img src="${avatarSrc}" alt="${post.display_name}'s avatar" class="post-avatar">
                <div class="post-user-info">
                    <span class="post-display-name">${post.display_name}</span>
                    <div class="post-meta">
                         <span class="post-timestamp">${timeAgo(post.created_at)}</span> &middot; <span class="post-privacy-icon">${getPrivacyIcon(post.privacy)}</span>
                    </div>
                </div>
                ${actionsMenuHTML}
            </div>
            ${post.content ? `<div class="post-content">${post.content.replace(/\n/g, '<br>')}</div>` : ''}
            ${post.image_url ? `<img src="/api/posts/images/${post.image_url}" alt="Post image" class="post-image">` : ''}
            <div class="post-stats">
                <span class="like-count-span">${post.like_count} Likes</span>
                <span class="comment-count-span">${post.comment_count} Comments</span>
            </div>
            <div class="post-actions">
                <button class="like-btn ${post.liked_by_user ? 'liked' : ''}"><i class="fa-solid fa-thumbs-up"></i> Like</button>
                <button class="comment-btn"><i class="fa-solid fa-comment"></i> Comment</button>
            </div>`;
        container.appendChild(postEl);
    };

    const loadPosts = async (isInitial = false) => {
        if (!hasMorePosts || isFeedLoading) return;
        isFeedLoading = true;
        loadMorePostsBtn.textContent = 'Loading...';
        try {
            if (isInitial) { postList.innerHTML = ''; feedPageCounter = 0; hasMorePosts = true; }
            const data = await apiRequest(`/api/posts?page=${feedPageCounter}`);
            data.posts.forEach(p => renderPost(p, postList));
            hasMorePosts = data.hasNext;
            feedPageCounter++;
            loadMorePostsBtn.style.display = hasMorePosts ? 'block' : 'none';
        } catch (err) { showToast('Failed to load posts.', 'error'); } 
        finally { isFeedLoading = false; loadMorePostsBtn.textContent = 'Load More'; }
    };

    // --- HÀM loadComments ĐÃ ĐƯỢC CHỈNH SỬA ---
    const loadComments = async (postId, isInitial = true, parentCommentId = null) => {
        if (isCommentsLoading && !isInitial && !parentCommentId) return;
        isCommentsLoading = true;
        
        const endpoint = `/api/posts/${postId}/comments?page=${commentPageCounter}`;
        const container = commentsList;
        
        let loadMoreBtnEl = D('load-more-comments-btn');

        if(loadMoreBtnEl) loadMoreBtnEl.textContent = 'Loading...';

        if (isInitial) {
            container.innerHTML = '<li>Loading comments...</li>';
            commentPageCounter = 0;
            hasMoreComments = true;
        }

        try {
            const data = await apiRequest(endpoint);
            
            // LÀM TRỐNG DANH SÁCH CHỈ KHI TẢI LẦN ĐẦU (ĐÃ LẤY ĐƯỢC DỮ LIỆU)
            if (isInitial) container.innerHTML = '';

            if (data.comments.length === 0) {
                if (isInitial) container.innerHTML = '<li>No comments yet.</li>';
            } else {
                const fragment = document.createDocumentFragment();
                
                // API trả về DESC (mới nhất trước).
                // Khi tải lần đầu, chèn vào đầu (prepend) để giữ thứ tự: Mới nhất -> Cũ nhất.
                // Khi tải thêm (View More), chèn vào cuối (appendChild) để bình luận cũ hơn nằm dưới cùng.
                data.comments.forEach(comment => { 
                    const li = document.createElement('li');
                    li.className = 'comment-item';
                    li.dataset.commentId = comment.id;
                    li.dataset.replyCount = comment.reply_count;
                    const avatarSrc = comment.avatar_url && comment.avatar_url !== 'macdinh.jpg' ? `/api/avatars/${comment.avatar_url}` : '/macdinh.jpg';
                    
                    // Logic hiển thị replies (giả định)
                    let repliesHtml = '';
                    if (comment.reply_count > 0) {
                        repliesHtml = `
                            <div class="replies-container">
                                <button class="view-replies-btn" data-parent-id="${comment.id}">${comment.reply_count} replies</button>
                                <ul class="replies-list" style="display: none;"></ul>
                            </div>
                        `;
                    }
                    
                    li.innerHTML = `
                        <img src="${avatarSrc}" alt="${comment.display_name}'s avatar" class="comment-avatar">
                        <div class="comment-content-wrapper">
                            <div class="comment-body">
                                <span class="comment-user" data-username="${comment.username}">${comment.display_name}</span>
                                <p class="comment-content">${comment.content}</p>
                            </div>
                            <div class="comment-actions">
                                <span class="comment-timestamp">${timeAgo(comment.created_at)}</span>
                                <button class="reply-btn">Reply</button>
                            </div>
                            ${repliesHtml}
                            <div class="reply-form-container" style="display: none;">
                                <form class="reply-form">
                                    <input type="text" placeholder="Write a reply..." required>
                                    <button type="submit">Post</button>
                                </form>
                            </div>
                        </div>
                    `;
                    fragment.appendChild(li); // Thêm vào fragment
                });
                
                // Nếu là tải lần đầu HOẶC tải lại sau khi post (isInitial=true), chèn lên đầu
                if (isInitial) {
                    container.prepend(fragment); 
                } else {
                    // Nếu là tải trang tiếp theo (View More), chèn vào cuối
                    container.appendChild(fragment); 
                }
            }
            
            // Cập nhật paging cho bình luận gốc
            if (!parentCommentId) {
                commentPageCounter++;
                hasMoreComments = data.hasNext;
                
                if (!loadMoreBtnEl && commentsModal.querySelector('.modal-body')) {
                    loadMoreBtnEl = document.createElement('button');
                    loadMoreBtnEl.id = 'load-more-comments-btn';
                    loadMoreBtnEl.className = 'view-more-btn';
                    commentsModal.querySelector('.modal-body').appendChild(loadMoreBtnEl);
                    loadMoreBtnEl.addEventListener('click', () => loadComments(activePostIdForComments, false));
                }
                if (loadMoreBtnEl) {
                    loadMoreBtnEl.textContent = 'View More Comments';
                    loadMoreBtnEl.style.display = hasMoreComments ? 'block' : 'none';
                }
            }

        } catch (err) {
            if (isInitial) container.innerHTML = '<li>Failed to load comments.</li>';
        } finally {
            isCommentsLoading = false;
        }
    };
    // --- KẾT THÚC HÀM loadComments ĐÃ CHỈNH SỬA ---

    // --- SEARCH LOGIC ---
    const executeSearch = async (isInitial = true) => {
        if (isSearchLoading) return;
        isSearchLoading = true;
        loadMoreSearchPostsBtn.textContent = 'Loading...';
        if(isInitial) { searchUserResults.innerHTML = ''; searchPostResults.innerHTML = ''; searchPostPageCounter = 0; hasMoreSearchPosts = true; }
        try {
            const data = await apiRequest(`/api/search?q=${encodeURIComponent(currentSearchQuery)}&page=${searchPostPageCounter}`);
            if (isInitial) {
                if (data.users.length > 0) {
                     D('search-users-section').style.display = 'block';
                     searchUserResults.innerHTML = ''; // Clear previous results
                     data.users.forEach(user => {
                         const li = document.createElement('li');
                         li.className = 'search-user-item';
                         li.dataset.username = user.username;
                         li.dataset.userId = user.id;
                         const avatarContainer = document.createElement('div');
                         avatarContainer.style.position = 'relative'; // Container cho avatar và indicator
                         const avatarSrc = user.avatar_url && user.avatar_url !== 'macdinh.jpg' ? `/api/avatars/${user.avatar_url}` : '/macdinh.jpg';
                         const avatarImg = document.createElement('img');
                         avatarImg.src = avatarSrc;
                         avatarContainer.appendChild(avatarImg);
                         addOnlineIndicator(avatarContainer, user.id); // Truyền avatar container
                         li.appendChild(avatarContainer);
                         const infoDiv = document.createElement('div');
                         infoDiv.className = 'search-user-info';
                         infoDiv.innerHTML = `<span class="display-name">${user.display_name}</span><span class="username">@${user.username}</span>`;
                         li.appendChild(infoDiv);
                         li.addEventListener('click', () => openProfileModal(user.username));
                         searchUserResults.appendChild(li);
                     });
                } else { D('search-users-section').style.display = 'none'; }
            }
            if (data.posts.results.length > 0) {
                 D('search-posts-section').style.display = 'block';
                 if (isInitial) searchPostResults.innerHTML = ''; // Clear previous posts
                 data.posts.results.forEach(p => renderPost(p, searchPostResults));
                 hasMoreSearchPosts = data.posts.hasNext;
                 loadMoreSearchPostsBtn.style.display = hasMoreSearchPosts ? 'block' : 'none';
                 searchPostPageCounter++;
            } else if (isInitial) {
                searchPostResults.innerHTML = '<p>No posts found matching your query.</p>';
                D('search-posts-section').style.display = 'block';
                loadMoreSearchPostsBtn.style.display = 'none';
            }
        } catch(err) { showToast(`Search failed: ${err.message}`, 'error'); } 
        finally { isSearchLoading = false; loadMoreSearchPostsBtn.textContent = 'Load More'; }
    };
    
    // --- FRIENDSHIP LOGIC ---
    const updateFriendRequestBadge = (count) => {
        friendRequestCount = count;
        friendRequestBadge.style.display = friendRequestCount > 0 ? 'flex' : 'none';
        if (friendRequestCount > 0) friendRequestBadge.textContent = friendRequestCount > 9 ? '9+' : friendRequestCount;
    };

    const renderFriendItem = (user, type) => {
        const li = document.createElement('li');
        li.className = 'friend-item';
        li.dataset.userId = user.id;
        li.dataset.username = user.username;
        const avatarContainer = document.createElement('div');
        avatarContainer.style.position = 'relative';
        const avatarSrc = user.avatar_url && user.avatar_url !== 'macdinh.jpg' ? `/api/avatars/${user.avatar_url}` : '/macdinh.jpg';
        const img = document.createElement('img');
        img.src = avatarSrc;
        img.alt = `${user.display_name}'s avatar`;
        avatarContainer.appendChild(img);
        
        addOnlineIndicator(avatarContainer, user.id); 
        
        let actionsHTML = '';
        if (type === 'request') {
            actionsHTML = `<div class="friend-item-actions"><button class="accept-friend-btn" data-user-id="${user.id}">Accept</button><button class="decline-friend-btn" data-user-id="${user.id}">Decline</button></div>`;
        }
        
        li.appendChild(avatarContainer);
        const infoDiv = document.createElement('div');
        infoDiv.className = 'friend-info';
        infoDiv.innerHTML = `<span class="display-name">${user.display_name}</span><span class="username">@${user.username}</span>`;
        li.appendChild(infoDiv);
        if (actionsHTML) li.innerHTML += actionsHTML;
        
        return li;
    };

    const loadFriendRequests = async () => {
        try {
            const requests = await apiRequest('/api/friends/requests');
            friendRequestsList.innerHTML = '';
            if (requests.length > 0) {
                friendRequestsSection.style.display = 'block';
                requests.forEach(user => friendRequestsList.appendChild(renderFriendItem(user, 'request')));
            } else { friendRequestsSection.style.display = 'none'; }
            updateFriendRequestBadge(requests.length);
        } catch (err) { showToast('Failed to load friend requests.', 'error'); }
    };

    const loadFriendsList = async () => {
        try {
            // Cập nhật trạng thái online trước
            const onlineIds = await apiRequest('/api/friends/online');
            onlineFriendIds = new Set(onlineIds.map(id => parseInt(id)));
            
            const friends = await apiRequest('/api/friends/list');
            myFriendsList.innerHTML = '';
            
            if (friends.length === 0) { myFriendsList.innerHTML = '<p>You have no friends yet. Find people using the search bar!</p>'; } 
            else { 
                friends.forEach(user => {
                    myFriendsList.appendChild(renderFriendItem(user, 'friend'));
                });
            }
        } catch (err) { showToast('Failed to load friends list.', 'error'); }
    };

    const handleAddFriend = async (e) => { const { userId, username } = e.target.closest('[data-user-id]').dataset; try { await apiRequest('/api/friends/request', { method: 'POST', body: JSON.stringify({ recipientId: userId }) }); showToast(`Friend request sent to ${username}`, 'success'); if (profileViewModal.classList.contains('active')) updateProfileActions(username, userId, { friendship: { status: 'pending', isRequester: true }, isBlocked: false }); } catch (err) { showToast(`Error: ${err.message}`, 'error'); } };
    const handleCancelRequest = async (e) => { const { userId, username } = e.target.closest('[data-user-id]').dataset; try { await apiRequest('/api/friends/remove', { method: 'POST', body: JSON.stringify({ friendId: userId }) }); showToast(`Friend request to ${username} cancelled.`, 'info'); if (profileViewModal.classList.contains('active')) updateProfileActions(username, userId, { friendship: { status: 'none' }, isBlocked: false }); } catch (err) { showToast(`Error: ${err.message}`, 'error'); } };
    const handleAcceptRequest = async (e) => { const { userId, username } = e.target.closest('[data-user-id]').dataset; try { await apiRequest('/api/friends/accept', { method: 'POST', body: JSON.stringify({ requesterId: userId }) }); showToast(`You are now friends with ${username || 'the user'}!`, 'success'); if (currentView === 'friends') { loadFriendRequests(); loadFriendsList(); } else if (profileViewModal.classList.contains('active')) { updateProfileActions(username, userId, { friendship: { status: 'accepted' }, isBlocked: false }); } } catch (err) { showToast(`Error: ${err.message}`, 'error'); } };
    const handleDeclineRequest = async (e) => { const { userId } = e.target.closest('[data-user-id]').dataset; try { await apiRequest('/api/friends/remove', { method: 'POST', body: JSON.stringify({ friendId: userId }) }); showToast(`Friend request declined.`, 'info'); if (currentView === 'friends') { loadFriendRequests(); } else if (profileViewModal.classList.contains('active')) { closeModal('profile-view-modal'); } } catch (err) { showToast(`Error: ${err.message}`, 'error'); } };
    const handleRemoveFriend = async (e) => { const { userId, username } = e.target.closest('[data-user-id]').dataset; const confirmed = await showConfirmation('Remove Friend', `Are you sure you want to remove ${username} from your friends?`, { danger: true }); if (confirmed) { try { await apiRequest('/api/friends/remove', { method: 'POST', body: JSON.stringify({ friendId: userId }) }); showToast(`${username} has been removed from your friends.`, 'info'); if (currentView === 'friends') { loadFriendsList(); } else if (profileViewModal.classList.contains('active')) { updateProfileActions(username, userId, { friendship: { status: 'none' }, isBlocked: false }); } } catch (err) { showToast(`Error: ${err.message}`, 'error'); } } };
    
    // --- NOTIFICATION LOGIC ---
    const getNotificationText = (n) => { const s = `<strong>${n.sender_name}</strong>`; switch (n.type) { case 'like': return `${s} liked your post.`; case 'comment': return `${s} commented on your post.`; case 'friend_accept': return `${s} accepted your friend request.`; case 'room_invite': return `${s} invited you to a group.`; case 'room_promotion': return `You have been promoted to admin in a group.`; case 'mention': return `${s} mentioned you in a chat.`; default: return 'You have a new notification.'; } };
    const renderNotification = (n, prepend = false) => { const li = document.createElement('li'); li.className = 'notification-item'; if (!n.is_read) li.classList.add('unread'); li.dataset.relatedId = n.related_id; li.dataset.type = n.type; const avatarSrc = n.sender_avatar && n.sender_avatar !== 'macdinh.jpg' ? `/api/avatars/${n.sender_avatar}` : '/macdinh.jpg'; li.innerHTML = `<img src="${avatarSrc}" alt="${n.sender_name}'s avatar"><div class="notification-content"><p>${getNotificationText(n)}</p><div class="notification-time">${timeAgo(n.created_at)}</div></div>`; if (prepend) notificationList.prepend(li); else notificationList.appendChild(li); };
    const updateNotificationUI = (count) => { unreadNotifications = count; if (unreadNotifications > 0) { notificationBadge.textContent = unreadNotifications > 9 ? '9+' : unreadNotifications; notificationBadge.style.display = 'flex'; } else { notificationBadge.style.display = 'none'; } };
    const fetchNotifications = async () => { try { const notifications = await apiRequest('/api/notifications'); notificationList.innerHTML = ''; let unreadCount = 0; notifications.forEach(n => { if (!n.is_read) unreadCount++; renderNotification(n); }); updateNotificationUI(unreadCount); } catch (err) { console.error("Failed to fetch notifications", err); } };
    
    // --- MESSAGE REQUEST LOGIC ---
    const fetchAndRenderMessageRequests = async () => {
        try {
            const requests = await apiRequest('/api/message-requests');
            messageRequestList.innerHTML = '';
            if (requests.length > 0) {
                messageRequestsContainer.style.display = 'block';
                requests.forEach(req => {
                    const li = document.createElement('li');
                    li.innerHTML = `<span>From <strong>${req.display_name}</strong></span><div><button class="accept-invite-btn" data-action="accept" data-id="${req.id}">Accept</button><button class="decline-friend-btn" data-action="decline" data-id="${req.id}" style="margin-left: 5px;">Decline</button></div>`;
                    messageRequestList.appendChild(li);
                });
            } else { messageRequestsContainer.style.display = 'none'; }
        } catch (err) { console.error("Failed to fetch message requests", err); }
    };
    
    // --- ADMIN & MEMBER LOGIC ---
    const fetchAndRenderMembers = async () => {
        if (!currentRoomId) return;
        try {
            const members = await apiRequest(`/api/rooms/${currentRoomId}/members`);
            pendingList.innerHTML = ''; membersList.innerHTML = '';
            const currentUser = JSON.parse(localStorage.getItem('user'));
            const room = roomsData.find(r => r.id == currentRoomId);
            members.forEach(member => {
                const li = document.createElement('li');
                li.dataset.userId = member.id;
                const avatarContainer = document.createElement('div');
                avatarContainer.style.position = 'relative';
                const avatarSrc = member.avatar_url && member.avatar_url !== 'macdinh.jpg' ? `/api/avatars/${member.avatar_url}` : '/macdinh.jpg';
                const img = document.createElement('img');
                img.src = avatarSrc;
                avatarContainer.appendChild(img);
                addOnlineIndicator(avatarContainer, member.id);
                li.innerHTML = `<div class="member-info">${avatarContainer.innerHTML}<div><div class="member-name">${member.display_name}</div>${member.role === 'admin' ? '<span class="member-role">Admin</span>' : ''}</div></div><div class="member-actions"></div>`;
                const actionsContainer = li.querySelector('.member-actions');
                if (member.status === 'pending') {
                    actionsContainer.innerHTML = `<button class="approve-btn">Approve</button>`;
                    pendingList.appendChild(li);
                } else {
                    if (member.id !== currentUser.id) {
                        // FIX: Kiểm tra creator_id cho public rooms
                        if (room.type === 'public' && room.creator_id !== currentUser.id) {
                            // Non-creator admin cannot manage members
                        } else if (member.role === 'admin' && room.creator_id != member.id) {
                            actionsContainer.innerHTML += `<button class="demote-btn">Demote</button>`;
                        } else if (member.role !== 'admin') {
                            actionsContainer.innerHTML += `<button class="promote-btn">Promote</button>`;
                        }
                        if (room.creator_id != member.id) {
                            actionsContainer.innerHTML += `<button class="kick-btn">Kick</button>`;
                        }
                    }
                    membersList.appendChild(li);
                }
            });
            D('pending-section').style.display = pendingList.children.length > 0 ? 'block' : 'none';
        } catch (err) { console.error("Failed to fetch members:", err); showToast('Failed to load members.', 'error'); }
    };

    const updateAdminUIForRoom = async (roomId) => {
        if (roomId != currentRoomId) return;
        const room = roomsData.find(r => r.id == roomId);
        const user = JSON.parse(localStorage.getItem('user'));
        let isRoomAdmin = false;
        
        const isDirectMessage = room && room.type === 'direct';

        if (room && !isDirectMessage) {
            try {
                const members = await apiRequest(`/api/rooms/${roomId}/members`);
                const myRole = members.find(m => m.id === user.id)?.role;
                
                if (room.type === 'public') {
                    // Trong public room, chỉ creator_id có quyền admin
                    isRoomAdmin = room.creator_id === user.id;
                } else {
                    // Trong private room, role = 'admin' có quyền
                    isRoomAdmin = myRole === 'admin';
                }
            } catch (e) { /* Fails if not member, ignore */ }
        }

        manageRoomBtn.style.display = isRoomAdmin ? 'flex' : 'none';
        inviteUserBtn.style.display = isRoomAdmin && !isDirectMessage ? 'flex' : 'none';
        getInviteLinkBtn.style.display = isRoomAdmin && !isDirectMessage ? 'flex' : 'none';
        leaveRoomBtn.style.display = !isDirectMessage ? 'block' : 'none';
    };

    // --- CHAT LOGIC ---
    const displayMessage = (msg, prepend = false) => {
        const item = document.createElement('li');
        if (msg.nickname === 'SYSTEM') {
            item.className = 'system-message';
            item.textContent = msg.text;
        } else {
            item.dataset.messageId = msg.id;
            item.dataset.senderUsername = msg.username;
            item.dataset.senderNickname = msg.nickname;
            item.dataset.timestamp = msg.timestamp;
            item.dataset.userId = msg.user_id || 0; 
            item.dataset.parentMessageId = msg.parent_message_id || 0; // Thêm parent_message_id
            
            const currentUser = JSON.parse(localStorage.getItem('user'));
            const isMyMessage = msg.username === currentUser?.username;
            item.className = `message-item ${isMyMessage ? 'my-message' : 'other-message'}`;
            
            const avatarContainer = document.createElement('div');
            avatarContainer.style.position = 'relative';
            const avatarSrc = msg.avatar_url && msg.avatar_url !== 'macdinh.jpg' ? `/api/avatars/${msg.avatar_url}` : '/macdinh.jpg';
            const avatarImg = document.createElement('img');
            avatarImg.src = avatarSrc;
            avatarImg.className = 'message-avatar';
            avatarContainer.appendChild(avatarImg);
            addOnlineIndicator(avatarContainer, msg.user_id);
            
            const actionsButtonHTML = (isMyMessage && !msg.is_deleted) ? `<button class="msg-actions-btn"><i class="fa-solid fa-ellipsis-vertical"></i></button>` : '';
            let messageContentHTML;
            if (msg.is_deleted) {
                item.classList.add('deleted');
                messageContentHTML = `<div class="message-content">[ Tin nhắn đã bị xóa ]</div>`;
            } else {
                const imageUrl = msg.imageUrl || msg.image_url;
                let content = '';
                // THAY THẾ DÒNG XỬ LÝ TEXT: Thêm logic @mention
                if (msg.text) {
                    const mentionRegex = /@(\w+)/g;
                    // Chuyển @username thành <a href="#" class="mention-link" data-username="$1">@$1</a>
                    const formattedText = msg.text.replace(mentionRegex, '<a href="#" class="mention-link" data-username="$1">@$1</a>');
                    content += `<p>${formattedText.replace(/\n/g, '<br>')}</p>`;
                }
                if (imageUrl) content += `<img src="/api/images/${imageUrl}" alt="User image">`;
                messageContentHTML = `<div class="message-content">${content}</div>`;
            }
            
            // Logic hiển thị Reply Preview (đơn giản)
            let replyToHTML = '';
            if (msg.parent_message_id) {
                replyToHTML = `<div class="reply-to-preview">Replying to message ${msg.parent_message_id}...</div>`; 
            }
            
            item.innerHTML = `
                ${avatarContainer.innerHTML}
                <div class="message-body">
                    ${!isMyMessage ? `<div class="message-meta-nickname">${msg.nickname}</div>` : ''}
                    ${replyToHTML} 
                    ${messageContentHTML}
                    <div class="message-meta">${new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                </div>
                ${actionsButtonHTML}`;
            item.querySelectorAll('img').forEach(img => img.onload = () => scrollToBottomIfNeeded());
        }
        if (prepend) messageList.insertBefore(item, messageList.firstChild);
        else messageList.appendChild(item);
    };

    const loadMessages = async (isInitialLoad = false) => {
        if (!hasMoreMessages[currentRoomId] || isLoading) return;
        isLoading = true;
        loadMoreBtn.disabled = true;
        loadMoreBtn.textContent = 'Loading...';
        try {
            const data = await apiRequest(`/api/rooms/${currentRoomId}/messages?page=${pageCounters[currentRoomId]}`);
            const oldScrollHeight = messagesContainer.scrollHeight;
            
            const messagesWithUserId = data.messages.map(msg => {
                const room = roomsData.find(r => r.id == currentRoomId);
                // Cần đảm bảo rằng `msg` có thuộc tính `username`
                const roomMember = room?.members?.find(m => m.username === msg.username);
                return { ...msg, user_id: roomMember?.id || 0 };
            });

            messagesWithUserId.reverse().forEach(msg => isInitialLoad ? displayMessage(msg, false) : displayMessage(msg, true));
            
            if (isInitialLoad) scrollToBottomIfNeeded(true);
            else messagesContainer.scrollTop = messagesContainer.scrollHeight - oldScrollHeight;
            pageCounters[currentRoomId]++;
            hasMoreMessages[currentRoomId] = data.hasNext;
            loadMoreBtn.style.display = hasMoreMessages[currentRoomId] ? 'block' : 'none';
        } catch (err) { console.error(err); showToast('Failed to load messages.', 'error'); loadMoreBtn.textContent = 'Error! Click to retry.'; } 
        finally { isLoading = false; loadMoreBtn.disabled = false; if (hasMoreMessages[currentRoomId]) loadMoreBtn.textContent = 'Load Older Messages'; }
    };

    const addUnreadBadge = (roomId) => { const roomLi = document.querySelector(`.room-list li[data-room-id='${roomId}']`); if (roomLi && !roomLi.classList.contains('unread')) { roomLi.classList.add('unread'); if (!roomLi.querySelector('.unread-badge')) { const badge = document.createElement('span'); badge.className = 'unread-badge'; roomLi.appendChild(badge); } } };
    const removeUnreadBadge = (roomId) => { const roomLi = document.querySelector(`.room-list li[data-room-id='${roomId}']`); if (roomLi && roomLi.classList.contains('unread')) { roomLi.classList.remove('unread'); const badge = roomLi.querySelector('.unread-badge'); if (badge) badge.remove(); } };

    const selectRoom = (roomId) => {
        if (socket && roomId != currentRoomId) {
            removeUnreadBadge(roomId);
            currentRoomId = roomId;
            document.querySelectorAll('.room-list li').forEach(li => li.classList.toggle('active', li.dataset.roomId == roomId));
            chatPlaceholder.style.display = 'none';
            chatContainer.style.display = 'flex';
            chatHeaderActions.style.display = 'flex';
            const room = roomsData.find(r => r.id == roomId);
            chatRoomName.textContent = room.name; 
            updateAdminUIForRoom(roomId);
            // Reset reply state
            replyingToMessage = null;
            replyPreviewContainer.style.display = 'none';
            
            socket.emit('join room', roomId, (response) => {
                if (response.success) {
                    messageList.innerHTML = '';
                    pageCounters[roomId] = 0;
                    hasMoreMessages[roomId] = true;
                    loadMessages(true);
                } else showToast(`Error joining room: ${response.message}`, 'error');
            });
        }
    };

    const fetchAndRenderRooms = async () => {
            try {
                roomsData = await apiRequest('/api/rooms');
                publicRoomList.innerHTML = '';
                privateRoomList.innerHTML = '';
                
                roomsData.forEach(room => {
                    const li = document.createElement('li');
                    li.dataset.roomId = room.id;

                    let avatarHTML = '';
                    let partnerId = null;

                    if (room.type === 'direct') {
                        // Chat 1-1: Lấy avatar của đối tác
                        const avatarSrc = room.partner_avatar && room.partner_avatar !== 'macdinh.jpg'
                                    ? `/api/avatars/${room.partner_avatar}`
                                    : '/macdinh.jpg';
                        partnerId = room.partner_id; // Lấy ID của đối tác để kiểm tra online
                        avatarHTML = `<img src="${avatarSrc}" alt="${room.name}'s avatar" class="room-avatar-img">`;
                    } else if (room.type === 'private') {
                        // Nhóm riêng tư: Dùng icon nhóm
                        avatarHTML = `<div class="room-icon-placeholder"><i class="fa-solid fa-user-group"></i></div>`;
                    } else {
                        // Nhóm công khai: Dùng icon hashtag
                        avatarHTML = `<div class="room-icon-placeholder"><i class="fa-solid fa-hashtag"></i></div>`;
                    }

                    // Tạo container cho avatar (để chứa online indicator)
                    const avatarContainer = document.createElement('div');
                    avatarContainer.className = 'room-list-avatar';
                    avatarContainer.innerHTML = avatarHTML;

                    // Thêm online indicator nếu là chat 1-1 và có partnerId
                    if (partnerId) {
                        addOnlineIndicator(avatarContainer, partnerId);
                    }

                    // Tạo tên phòng
                    const infoDiv = document.createElement('div');
                    infoDiv.className = 'room-list-info';
                    infoDiv.textContent = room.name;

                    // Thêm avatar và tên vào <li>
                    li.appendChild(avatarContainer);
                    li.appendChild(infoDiv);

                    if (room.id == currentRoomId) li.classList.add('active');
                    
                    if (room.type === 'public') publicRoomList.appendChild(li);
                    else privateRoomList.appendChild(li); 
                });
            } catch (e) { console.error("Failed to fetch rooms", e); }
        };

    const fetchAndRenderInvitations = async () => {
        try {
            const invitations = await apiRequest('/api/invitations');
            invitationList.innerHTML = '';
            if (invitations.length > 0) {
                invitationsContainer.style.display = 'block';
                invitations.forEach(inv => {
                    const li = document.createElement('li');
                    li.innerHTML = `<span>Join <strong>${inv.room_name}</strong>?<br><small>(from ${inv.inviter_name})</small></span><button class="accept-invite-btn" data-id="${inv.id}">Accept</button>`;
                    invitationList.appendChild(li);
                });
            } else { invitationsContainer.style.display = 'none'; }
        } catch (err) { console.error("Failed to fetch invitations", err); }
    };

    // --- INIT & AUTH ---
    const initChat = async (token, user) => {
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
        authContainer.style.display = 'none';
        appWrapper.style.display = 'flex';
        headerDisplayName.textContent = user.display_name;
        headerUsername.textContent = `@${user.username}`;
        const avatarSrc = user.avatar_url && user.avatar_url !== 'macdinh.jpg' ? `/api/avatars/${user.avatar_url}` : '/macdinh.jpg';
        headerAvatar.src = avatarSrc; createPostAvatar.src = avatarSrc;
        
        // Initial load of online friends
        try {
            const onlineIds = await apiRequest('/api/friends/online');
            onlineFriendIds = new Set(onlineIds.map(id => parseInt(id)));
        } catch (e) { console.error("Failed to load initial online friends:", e); }
        
        const headerAvatarContainer = headerAvatar.closest('#user-profile');
        headerAvatarContainer.querySelector('.online-indicator')?.remove();
        if (onlineFriendIds.has(user.id)) addOnlineIndicator(headerAvatarContainer, user.id);
        
        chatRoomName.textContent = 'Select a Room';
        chatHeaderActions.style.display = 'none';
        switchView('feed');
        socket = io({ auth: { token } });
        socket.on('connect_error', () => { showToast('Authentication failed.', 'error'); handleLogout(); });
        socket.on('new_friend_request', (requester) => { showToast(`You have a new friend request from ${requester.display_name}!`, 'info'); friendRequestCount++; updateFriendRequestBadge(friendRequestCount); if (currentView === 'friends') { friendRequestsSection.style.display = 'block'; friendRequestsList.prepend(renderFriendItem(requester, 'request')); } });
        socket.on('friend_list_updated', () => { showToast('Your friends list has been updated.', 'info'); if(currentView === 'friends') { loadFriendRequests(); loadFriendsList(); } else { loadFriendRequests(); } });
        socket.on('new_notification', (n) => { const cleanText = getNotificationText(n).replace(/<strong>|<\/strong>/g, ''); showToast(cleanText, 'info'); n.created_at = new Date(); renderNotification(n, true); unreadNotifications++; updateNotificationUI(unreadNotifications); });
        socket.on('chat message', (msg) => { if (msg.roomId == currentRoomId) { displayMessage(msg); scrollToBottomIfNeeded(); } else { addUnreadBadge(msg.roomId); showToast(`New message in conversation`, 'info'); } });
        socket.on('message_deleted', ({ messageId, roomId }) => { if (roomId == currentRoomId) { const msgLi = document.querySelector(`li[data-message-id='${messageId}']`); if (msgLi) { msgLi.classList.add('deleted'); const contentDiv = msgLi.querySelector('.message-content'); if (contentDiv) contentDiv.innerHTML = '[ Tin nhắn đã bị xóa ]'; const actionsBtn = msgLi.querySelector('.msg-actions-btn'); if (actionsBtn) actionsBtn.remove(); if (imageViewerModal.classList.contains('active') && imageViewerDeleteBtn.dataset.messageId == messageId) closeModal('image-viewer-modal'); } } });
        socket.on('system message', (msg) => { if (msg.roomId == currentRoomId) { displayMessage({ nickname: 'SYSTEM', ...msg }); scrollToBottomIfNeeded(); } else { showToast(msg.text, 'warning'); } });
        socket.on('new_pending_member', ({ roomName }) => { showToast(`A new member is awaiting approval in group: "${roomName}"`, 'info'); if(manageRoomModal.classList.contains('active')) fetchAndRenderMembers(); });
        socket.on('role_updated', ({ roomId }) => { updateAdminUIForRoom(roomId); });
        socket.on('kicked', ({ roomId, roomName }) => { showToast(`You have been kicked from the group: "${roomName}"`, 'warning'); if (roomId == currentRoomId) { chatContainer.style.display = 'none'; chatPlaceholder.style.display = 'flex'; currentRoomId = null; } fetchAndRenderRooms(); });
        socket.on('member_list_updated', ({ roomId }) => { if (roomId == currentRoomId && manageRoomModal.classList.contains('active')) { showToast('Member list updated!', 'info'); fetchAndRenderMembers(); } });
        socket.on('room_list_updated', () => { showToast('Your conversation list was updated!', 'info'); fetchAndRenderRooms(); });
        socket.on('user_typing', ({ username, roomId }) => { if (roomId == currentRoomId) typingIndicator.textContent = `${username} is typing...`; });
        socket.on('user_stopped_typing', ({ roomId }) => { if (roomId == currentRoomId) typingIndicator.textContent = ''; });
        socket.on('new_message_request', (data) => { showToast(`You have a new message request from ${data.sender_name}`, 'info'); fetchAndRenderMessageRequests(); });
        
        // Cập nhật trạng thái online của bạn bè
        socket.on('friend_online', ({ userId }) => { onlineFriendIds.add(userId); showToast('A friend just came online!', 'info'); if (currentView === 'friends') loadFriendsList(); if (currentView === 'search') executeSearch(true); });
        socket.on('friend_offline', ({ userId }) => { onlineFriendIds.delete(userId); if (currentView === 'friends') loadFriendsList(); if (currentView === 'search') executeSearch(true); });

        fetchAndRenderRooms();
        fetchAndRenderInvitations();
        loadFriendRequests();
        fetchNotifications();
        fetchAndRenderMessageRequests();
        handlePendingInvite();
    };

    const handleLogout = () => { if (socket) socket.disconnect(); localStorage.clear(); authContainer.style.display = 'none'; appWrapper.style.display = 'none'; chatRoomName.textContent = ''; chatHeaderActions.style.display = 'none'; window.location.href = '/'; };
    const handlePendingInvite = async () => { const inviteLinkId = localStorage.getItem('pendingInvite'); if (!inviteLinkId) return; const token = localStorage.getItem('token'); if (!token) { authContainer.style.display = 'block'; showAuthMessage('Please log in or register to join the room.', 'login'); return; } localStorage.removeItem('pendingInvite'); try { const data = await apiRequest(`/api/rooms/join/${inviteLinkId}`, { method: 'POST' }); showToast(data.message, 'success'); await fetchAndRenderRooms(); } catch (err) { showToast(err.message, 'error'); } };
    const handleTyping = () => { if (!socket || !currentRoomId) return; socket.emit('typing_start', { roomId: currentRoomId }); clearTimeout(typingTimer); typingTimer = setTimeout(() => socket.emit('typing_stop', { roomId: currentRoomId }), TYPING_TIMER_LENGTH); };

    // --- EVENT LISTENERS ---
    navFeedBtn.addEventListener('click', () => switchView('feed'));
    navChatBtn.addEventListener('click', () => switchView('chat'));
    navFriendsBtn.addEventListener('click', () => switchView('friends'));
    searchForm.addEventListener('submit', (e) => { e.preventDefault(); const query = searchInput.value.trim(); if(query) { currentSearchQuery = query; searchQueryDisplay.textContent = query; switchView('search'); executeSearch(true); } });
    loadMoreSearchPostsBtn.addEventListener('click', () => executeSearch(false));
    goToRegisterLink.addEventListener('click', () => switchForm('register'));
    goToLoginLink.addEventListener('click', () => switchForm('login'));
    loginForm.addEventListener('submit', async (e) => { e.preventDefault(); try { const data = await apiRequest('/login', { method: 'POST', body: JSON.stringify({ username: D('log-username').value, password: D('log-password').value }) }); initChat(data.accessToken, data.user); } catch (err) { showAuthMessage(err.message, 'login'); } });
    registerForm.addEventListener('submit', async (e) => { e.preventDefault(); const formData = new FormData(registerForm); const username = formData.get('username'); try { const data = await apiRequest('/register', { method: 'POST', body: formData }); showAuthMessage(data.message, 'register', 'success'); setTimeout(() => { switchForm('login'); D('log-username').value = username; D('log-password').focus(); }, 1500); } catch (err) { showAuthMessage(err.message, 'register'); } });
    
    // THAY THẾ: messageForm.addEventListener('submit', ...) để hỗ trợ Reply
    messageForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = messageInput.value.trim();
        
        if ((text || replyingToMessage) && socket && currentRoomId) {
            const payload = { 
                text: text || null, 
                roomId: currentRoomId,
                parent_message_id: replyingToMessage ? replyingToMessage.id : null
            };
            socket.emit('chat message', payload);

            // Reset UI sau khi gửi
            messageInput.value = '';
            messageInput.style.height = 'auto';
            replyingToMessage = null;
            replyPreviewContainer.style.display = 'none';
            
            socket.emit('typing_stop', { roomId: currentRoomId });
            clearTimeout(typingTimer);
        }
    });

    messageInput.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); messageForm.requestSubmit(); } });
    messageInput.addEventListener('input', () => { messageInput.style.height = 'auto'; messageInput.style.height = (messageInput.scrollHeight) + 'px'; handleTyping(); });
    logoutBtn.addEventListener('click', handleLogout);
    publicRoomList.addEventListener('click', (e) => { const li = e.target.closest('li'); if (li) selectRoom(li.dataset.roomId); });
    privateRoomList.addEventListener('click', (e) => { const li = e.target.closest('li'); if (li) selectRoom(li.dataset.roomId); });
    messagesContainer.addEventListener('scroll', () => { if (messagesContainer.scrollTop === 0 && !isLoading) loadMessages(false); });

    friendsView.addEventListener('click', e => {
        const target = e.target;
        const friendItem = target.closest('.friend-item');
        if (!friendItem) return;
        if (target.classList.contains('accept-friend-btn')) handleAcceptRequest(e);
        else if (target.classList.contains('decline-friend-btn')) handleDeclineRequest(e);
        else if (target.closest('.friend-info') || target.closest('img')) { const username = friendItem.dataset.username; if (username) openProfileModal(username); }
    });

    notificationBellBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const isVisible = notificationPanel.style.display === 'block';
        notificationPanel.style.display = isVisible ? 'none' : 'block';
        if (!isVisible && unreadNotifications > 0) {
            setTimeout(async () => { try { await apiRequest('/api/notifications/mark-read', { method: 'POST' }); notificationList.querySelectorAll('.unread').forEach(item => item.classList.remove('unread')); updateNotificationUI(0); } catch (err) { console.error("Failed to mark notifications as read", err); } }, 2000);
        }
    });

    markAllReadBtn.addEventListener('click', async (e) => { e.stopPropagation(); try { await apiRequest('/api/notifications/mark-read', { method: 'POST' }); notificationList.querySelectorAll('.unread').forEach(item => item.classList.remove('unread')); updateNotificationUI(0); showToast('All notifications marked as read.', 'success'); } catch (err) { showToast('Failed to mark notifications as read.', 'error'); } });

    window.addEventListener('click', (e) => {
        if (messageContextMenu.style.display === 'block') messageContextMenu.style.display = 'none';
        if (notificationPanel.style.display === 'block' && !notificationPanel.contains(e.target) && !notificationBellBtn.contains(e.target)) notificationPanel.style.display = 'none';
        document.querySelectorAll('.post-actions-menu').forEach(menu => { if (!menu.previousElementSibling.contains(e.target)) menu.style.display = 'none'; });
    });

    messageList.addEventListener('click', async (e) => {
        const target = e.target;
        const messageLi = target.closest('.message-item');
        if (!messageLi) return;
        
        // Xử lý click vào @mention
        if (target.classList.contains('mention-link')) {
            e.preventDefault();
            const username = target.dataset.username;
            if (username) openProfileModal(username);
            return;
        }

        const profileTrigger = target.closest('.message-avatar, .message-meta-nickname');
        if (profileTrigger) { const username = messageLi.dataset.senderUsername; if (username) openProfileModal(username); return; }
        if (target.closest('.msg-actions-btn')) { e.stopPropagation(); const messageId = messageLi.dataset.messageId; const rect = target.closest('.msg-actions-btn').getBoundingClientRect(); const menuWidth = 180; let leftPosition = rect.left + window.scrollX - menuWidth; if (leftPosition < 0) leftPosition = rect.left + window.scrollX; messageContextMenu.style.top = `${rect.bottom + window.scrollY}px`; messageContextMenu.style.left = `${leftPosition}px`; messageContextMenu.dataset.messageId = messageId; messageContextMenu.style.display = 'block'; return; }
        if (target.tagName === 'IMG' && target.closest('.message-content')) { 
            const currentUser = JSON.parse(localStorage.getItem('user')); 
            const { senderUsername, senderNickname, timestamp, messageId } = messageLi.dataset; 
            imageViewerImg.src = target.src; 
            imageViewerSender.textContent = `Sent by: ${senderNickname}`; 
            imageViewerTime.textContent = new Date(timestamp).toLocaleString(); 
            
            if (currentUser.username === senderUsername) { 
                imageViewerDeleteBtn.style.display = 'flex'; 
                imageViewerDeleteBtn.dataset.messageId = messageId; 
            } else { 
                imageViewerDeleteBtn.style.display = 'none'; 
            } 
            openModal('image-viewer-modal'); 
        }
    });

    D('context-menu-delete').addEventListener('click', async () => { const messageId = messageContextMenu.dataset.messageId; messageContextMenu.style.display = 'none'; const confirmed = await showConfirmation('Delete Message', 'Are you sure you want to delete this message? This action cannot be undone.', { danger: true }); if (confirmed) { try { await apiRequest(`/api/messages/${messageId}/delete`, { method: 'PUT' }); } catch (err) { showToast(`Failed to delete message: ${err.message}`, 'error'); } } });
    
    // Xử lý khi nhấn nút Reply trong context menu tin nhắn
    D('context-menu-reply').addEventListener('click', () => {
        const messageId = messageContextMenu.dataset.messageId;
        const messageLi = document.querySelector(`.message-item[data-message-id='${messageId}']`);
        if (messageLi) {
            replyingToMessage = {
                id: messageId,
                sender: messageLi.dataset.senderNickname,
                text: messageLi.querySelector('.message-content p')?.textContent || 'Image'
            };
            replyPreviewSender.textContent = `Replying to ${replyingToMessage.sender}`;
            replyPreviewText.textContent = replyingToMessage.text;
            replyPreviewContainer.style.display = 'flex';
            messageInput.focus();
        }
        messageContextMenu.style.display = 'none';
    });
    
    // Xử lý khi đóng preview trả lời tin nhắn
    closeReplyPreviewBtn.addEventListener('click', () => {
        replyingToMessage = null;
        replyPreviewContainer.style.display = 'none';
        messageInput.focus();
    });


    imageViewerDeleteBtn.addEventListener('click', async () => { const messageId = imageViewerDeleteBtn.dataset.messageId; const confirmed = await showConfirmation('Delete Message', 'Are you sure you want to delete this message?', { danger: true }); if (confirmed) { try { await apiRequest(`/api/messages/${messageId}/delete`, { method: 'PUT' }); closeModal('image-viewer-modal'); } catch (err) { showToast(`Failed to delete message: ${err.message}`, 'error'); } } });
    imageViewerModal.addEventListener('click', (e) => { if (e.target.classList.contains('image-viewer') || e.target.closest('.close-btn')) closeModal('image-viewer-modal'); });
    document.addEventListener('keydown', (e) => { if (e.key === "Escape" && imageViewerModal.classList.contains('active')) closeModal('image-viewer-modal'); });
    userProfile.addEventListener('click', () => { const currentUser = JSON.parse(localStorage.getItem('user')); if (currentUser) openProfileModal(currentUser.username); });
    avatarInput.addEventListener('change', () => { if (avatarInput.files.length > 0) avatarUploadForm.requestSubmit(); });
    avatarUploadForm.addEventListener('submit', async (e) => { e.preventDefault(); const formData = new FormData(); formData.append('avatar', avatarInput.files[0]); try { const data = await apiRequest('/api/upload-avatar', { method: 'POST', body: formData }); const user = JSON.parse(localStorage.getItem('user')); user.avatar_url = data.avatar_url; localStorage.setItem('user', JSON.stringify(user)); headerAvatar.src = `/api/avatars/${data.avatar_url}`; createPostAvatar.src = `/api/avatars/${data.avatar_url}`; D('profile-edit-avatar-preview').src = `/api/avatars/${data.avatar_url}`; showToast('Avatar updated!', 'success'); } catch (err) { showToast(`Upload failed: ${err.message}`, 'error'); } });
    regAvatarInput.addEventListener('change', () => { const file = regAvatarInput.files[0]; if (file) avatarPreview.src = URL.createObjectURL(file); });
    createRoomBtn.addEventListener('click', () => { const user = JSON.parse(localStorage.getItem('user')); publicRoomOption.style.display = user?.is_admin ? 'block' : 'none'; openModal('create-room-modal'); });
    document.querySelectorAll('.modal .close-btn').forEach(btn => btn.addEventListener('click', () => btn.closest('.modal').classList.remove('active')));
    submitCreateRoomBtn.addEventListener('click', async () => { try { const newRoom = await apiRequest('/api/rooms', { method: 'POST', body: JSON.stringify({ name: D('new-room-name').value, type: D('new-room-type').value }) }); closeModal('create-room-modal'); await fetchAndRenderRooms(); selectRoom(newRoom.id); } catch (err) { D('create-room-message').textContent = err.message; } });
    inviteUserBtn.addEventListener('click', () => { inviteSearchInput.value = ''; inviteSearchResults.innerHTML = ''; inviteUserMessage.textContent = ''; inviteSearchResults.style.display = 'none'; openModal('invite-user-modal'); });
    searchUserBtn.addEventListener('click', async () => { const query = inviteSearchInput.value.trim(); if (!query) return; inviteUserMessage.textContent = 'Searching...'; inviteSearchResults.style.display = 'none'; try { const users = await apiRequest(`/api/users/search?username=${encodeURIComponent(query)}`); inviteUserMessage.textContent = ''; inviteSearchResults.innerHTML = ''; if (!users || users.length === 0) { inviteUserMessage.textContent = 'No users found.'; return; } inviteSearchResults.style.display = 'block'; users.forEach(user => { const li = document.createElement('li'); li.innerHTML = `<div class="member-info"><img src="${user.avatar_url && user.avatar_url !== 'macdinh.jpg' ? `/api/avatars/${user.avatar_url}` : '/macdinh.jpg'}"><div><div class="member-name">${user.display_name}</div><small>@${user.username}</small></div></div><div class="member-actions"><button class="invite-btn" data-user-id="${user.id}">Invite</button></div>`; inviteSearchResults.appendChild(li); }); } catch (err) { inviteUserMessage.textContent = err.message; inviteSearchResults.innerHTML = ''; } });
    inviteSearchResults.addEventListener('click', async (e) => { if (e.target.classList.contains('invite-btn')) { const userIdToInvite = e.target.dataset.userId; const button = e.target; button.disabled = true; button.textContent = 'Inviting...'; try { const data = await apiRequest(`/api/rooms/${currentRoomId}/invite`, { method: 'POST', body: JSON.stringify({ userIdToInvite }) }); showToast(data.message, 'success'); button.textContent = 'Invited'; } catch (err) { showToast(err.message, 'error'); button.disabled = false; button.textContent = 'Invite'; } } });
    getInviteLinkBtn.addEventListener('click', () => { const room = roomsData.find(r => r.id == currentRoomId); inviteLinkText.value = `${window.location.origin}/join/${room.invite_link_id}`; openModal('invite-link-modal'); });
    copyInviteLinkBtn.addEventListener('click', () => { inviteLinkText.select(); document.execCommand('copy'); showToast('Link copied to clipboard!', 'success'); });
    invitationList.addEventListener('click', async (e) => { if (e.target.classList.contains('accept-invite-btn')) { try { await apiRequest(`/api/invitations/${e.target.dataset.id}/accept`, { method: 'POST' }); showToast('Invitation accepted!', 'success'); fetchAndRenderInvitations(); fetchAndRenderRooms(); } catch (err) { showToast('Failed to accept invitation.', 'error'); } } });
    manageRoomBtn.addEventListener('click', () => { fetchAndRenderMembers(); openModal('manage-room-modal'); });
    manageRoomModal.addEventListener('click', async (e) => { const target = e.target; const li = target.closest('li'); if (!li) return; const userId = li.dataset.userId; try { let actionConfirmed = false; let successMessage = ''; if (target.classList.contains('approve-btn')) { actionConfirmed = true; await apiRequest(`/api/rooms/${currentRoomId}/approve`, { method: 'POST', body: JSON.stringify({ userIdToApprove: userId }) }); successMessage = 'Member approved.'; } else if (target.classList.contains('promote-btn')) { actionConfirmed = await showConfirmation('Promote User', `Are you sure you want to make this user an admin?`); if (actionConfirmed) { await apiRequest(`/api/rooms/${currentRoomId}/promote`, { method: 'POST', body: JSON.stringify({ userIdToPromote: userId }) }); successMessage = 'Member promoted.'; } } else if (target.classList.contains('demote-btn')) { actionConfirmed = await showConfirmation('Demote Admin', `Are you sure you want to remove admin rights from this user?`, { danger: true }); if (actionConfirmed) { await apiRequest(`/api/rooms/${currentRoomId}/demote`, { method: 'POST', body: JSON.stringify({ userIdToDemote: userId }) }); successMessage = 'Admin demoted.'; } } else if (target.classList.contains('kick-btn')) { actionConfirmed = await showConfirmation('Kick Member', 'Are you sure you want to kick this member?', { danger: true }); if (actionConfirmed) { const roomName = roomsData.find(r => r.id == currentRoomId)?.name; await apiRequest(`/api/rooms/${currentRoomId}/kick`, { method: 'POST', body: JSON.stringify({ userIdToKick: userId, roomName }) }); successMessage = 'Member kicked.'; } } if (actionConfirmed) { showToast(successMessage, 'success'); fetchAndRenderMembers(); } } catch (err) { showToast(`Action failed: ${err.message}`, 'error'); } });
    leaveRoomBtn.addEventListener('click', async () => { if (currentRoomId) { const confirmed = await showConfirmation('Leave Group', 'Are you sure? If you are the last member, the group will be deleted.', { danger: true }); if (confirmed) { try { const data = await apiRequest(`/api/rooms/${currentRoomId}/leave`, { method: 'POST' }); if(data.roomDeleted) showToast("The group has been deleted.", 'warning'); else showToast("You have left the group.", 'info'); chatContainer.style.display = 'none'; chatPlaceholder.style.display = 'flex'; leaveRoomBtn.style.display = 'none'; currentRoomId = null; chatRoomName.textContent = 'Select a Room'; chatHeaderActions.style.display = 'none'; fetchAndRenderRooms(); } catch (err) { showToast(`Failed to leave group: ${err.message}`, 'error'); } } } });
    
    // Logic chuyển tab trong modal cài đặt
    D('profile-edit-modal').addEventListener('click', (e) => {
        if (e.target.matches('.modal-tab-btn')) {
            const tabId = e.target.dataset.tab;
            e.target.parentElement.querySelectorAll('.modal-tab-btn').forEach(btn => btn.classList.remove('active'));
            D('profile-edit-form').querySelectorAll('.modal-tab-content').forEach(content => content.classList.remove('active'));
            e.target.classList.add('active');
            D(`tab-${tabId}`).classList.add('active');
            
            // Focus vào input nếu cần
            if (tabId === 'password') D('edit-current-password-input').focus();
        }
    });

    profileEditForm.addEventListener('submit', async (e) => { 
        e.preventDefault(); 
        saveProfileBtn.disabled = true; 
        saveProfileBtn.textContent = 'Saving...'; 
        profileEditMessage.textContent = ''; 
        
        const body = { 
            display_name: editDisplayNameInput.value.trim(), 
            allow_stranger_messages: D('allow-stranger-msg-toggle').checked 
        }; 
        
        const newPassword = D('edit-new-password-input').value; 
        if (newPassword) {
            body.new_password = newPassword;
            body.current_password = D('edit-current-password-input').value;
            body.confirm_new_password = D('edit-confirm-password-input').value;
        }

        try { 
            const data = await apiRequest('/api/user/profile', { method: 'PUT', body: JSON.stringify(body) }); 
            // Cần cập nhật lại localStorage vì có thể token và user payload đã thay đổi (ví dụ: avatar_url, display_name)
            localStorage.setItem('token', data.accessToken); 
            localStorage.setItem('user', JSON.stringify(data.user)); 
            headerDisplayName.textContent = data.user.display_name; 
            headerUsername.textContent = `@${data.user.username}`;
            // Cập nhật lại avatar URL
            const newAvatarSrc = data.user.avatar_url && data.user.avatar_url !== 'macdinh.jpg' ? `/api/avatars/${data.user.avatar_url}` : '/macdinh.jpg';
            headerAvatar.src = newAvatarSrc;
            createPostAvatar.src = newAvatarSrc;
            
            showToast('Profile updated successfully!', 'success'); 
            closeModal('profile-edit-modal'); 
        } catch (err) { 
            profileEditMessage.textContent = err.message; 
        } finally { 
            saveProfileBtn.disabled = false; 
            saveProfileBtn.textContent = 'Save Changes'; 
        } 
    });
    
    // Xử lý khi nhấn nút Change Photo trong modal settings
    D('change-avatar-btn').addEventListener('click', () => { avatarInput.click(); });
    
    createPostForm.addEventListener('submit', async (e) => { e.preventDefault(); const content = createPostTextarea.value.trim(); const imageFile = postImageInput.files[0]; const privacy = postPrivacySelect.value; if (!content && !imageFile) return showToast('Please write something or add a photo.', 'warning'); submitPostBtn.disabled = true; submitPostBtn.textContent = 'Posting...'; const formData = new FormData(); formData.append('content', content); formData.append('privacy', privacy); if (imageFile) formData.append('image', imageFile); try { await apiRequest('/api/posts', { method: 'POST', body: formData }); showToast('Post created successfully!', 'success'); createPostTextarea.value = ''; postImageInput.value = ''; postImagePreview.style.display = 'none'; postImagePreview.src = ''; loadPosts(true); } catch (err) { showToast(`Failed to create post: ${err.message}`, 'error'); } finally { submitPostBtn.disabled = false; submitPostBtn.textContent = 'Post'; } });
    postImageInput.addEventListener('change', () => { const file = postImageInput.files[0]; if (file) { postImagePreview.src = URL.createObjectURL(file); postImagePreview.style.display = 'block'; } else { postImagePreview.src = ''; postImagePreview.style.display = 'none'; } });
    feedContent.addEventListener('scroll', () => { if (feedContent.scrollTop + feedContent.clientHeight >= feedContent.scrollHeight - 200) loadPosts(); });
    loadMorePostsBtn.addEventListener('click', () => loadPosts());
    editPostForm.addEventListener('submit', async (e) => { e.preventDefault(); const postId = e.target.dataset.postId; const newContent = D('edit-post-textarea').value.trim(); const saveBtn = D('save-post-changes-btn'); if (!newContent) { D('edit-post-message').textContent = 'Content cannot be empty.'; return; } saveBtn.disabled = true; saveBtn.textContent = 'Saving...'; try { await apiRequest(`/api/posts/${postId}`, { method: 'PUT', body: JSON.stringify({ content: newContent }) }); const postInFeed = document.querySelector(`.post-item[data-post-id='${postId}'] .post-content`); if (postInFeed) postInFeed.innerHTML = newContent.replace(/\n/g, '<br>'); closeModal('edit-post-modal'); showToast('Post updated successfully!', 'success'); } catch (err) { D('edit-post-message').textContent = err.message; } finally { saveBtn.disabled = false; saveBtn.textContent = 'Save Changes'; } });
    
    [postList, searchPostResults].forEach(container => {
        container.addEventListener('click', async (e) => {
            const target = e.target;
            const postItem = target.closest('.post-item');
            if (!postItem) return;
            const postId = postItem.dataset.postId;
            if (target.closest('.post-actions-btn')) { e.stopPropagation(); const menu = target.closest('.post-actions-container').querySelector('.post-actions-menu'); const isVisible = menu.style.display === 'block'; document.querySelectorAll('.post-actions-menu').forEach(m => m.style.display = 'none'); menu.style.display = isVisible ? 'none' : 'block'; return; }
            if (target.closest('.post-actions-menu li')) { const action = target.closest('li').dataset.action; if (action === 'edit') { const currentContent = postItem.querySelector('.post-content')?.innerText || ''; D('edit-post-textarea').value = currentContent; D('edit-post-form').dataset.postId = postId; D('edit-post-message').textContent = ''; openModal('edit-post-modal'); } else if (action === 'delete') { const confirmed = await showConfirmation('Delete Post', 'Are you sure you want to permanently delete this post?', { danger: true }); if (confirmed) { try { await apiRequest(`/api/posts/${postId}`, { method: 'DELETE' }); postItem.style.transition = 'opacity 0.5s ease'; postItem.style.opacity = '0'; setTimeout(() => postItem.remove(), 500); showToast('Post deleted successfully.', 'success'); } catch (err) { showToast(`Failed to delete post: ${err.message}`, 'error'); } } } return; }
            if (target.closest('.like-btn')) { const likeBtn = target.closest('.like-btn'); const likeCountSpan = postItem.querySelector('.like-count-span'); let likeCount = parseInt(likeCountSpan.textContent); try { likeBtn.classList.toggle('liked'); likeCount = likeBtn.classList.contains('liked') ? likeCount + 1 : likeCount - 1; likeCountSpan.textContent = `${likeCount} Likes`; await apiRequest(`/api/posts/${postId}/like`, { method: 'POST' }); } catch (err) { likeBtn.classList.toggle('liked'); likeCountSpan.textContent = `${likeBtn.classList.contains('liked') ? likeCount + 1 : likeCount - 1} Likes`; showToast('Could not update like.', 'error'); } }
            if(target.closest('.comment-btn')) { activePostIdForComments = postId; loadComments(postId, true); openModal('comments-modal'); }
            if (target.closest('.post-avatar, .post-display-name')) { const username = postItem.dataset.username; if(username) openProfileModal(username); }
        });
    });

    commentForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const content = commentInput.value.trim();
        if (!content || !activePostIdForComments) return;

        const btn = commentForm.querySelector('button');
        const originalText = btn.textContent;
        btn.disabled = true;
        btn.textContent = '...';

        try {
            // Gửi comment, nhận về dữ liệu đầy đủ (có created_at từ DB)
            const res = await apiRequest(`/api/posts/${activePostIdForComments}/comment`, {
                method: 'POST',
                body: JSON.stringify({ content })
            });

            commentInput.value = '';

            const c = res.comment; // dữ liệu chính xác từ DB

            // Tạo element hiển thị lên UI
            const li = document.createElement('li');
            li.className = 'comment-item';
            li.dataset.commentId = c.id;
            li.dataset.replyCount = 0;
            const avatarSrc = c.avatar_url && c.avatar_url !== 'macdinh.jpg'
                ? `/api/avatars/${c.avatar_url}` : '/macdinh.jpg';

            li.innerHTML = `
                <img src="${avatarSrc}" class="comment-avatar">
                <div class="comment-content-wrapper">
                    <div class="comment-body">
                        <span class="comment-user" data-username="${c.username}">${c.display_name}</span>
                        <p class="comment-content">${c.content}</p>
                    </div>
                    <div class="comment-actions">
                        <span class="comment-timestamp">${timeAgo(c.created_at)}</span>
                        <button class="reply-btn">Reply</button>
                    </div>
                </div>
            `;

            // Thêm lên đầu danh sách
            commentsList.prepend(li);

            // Cập nhật số lượng comment trên bài post trong feed
            const postInFeed = document.querySelector(`.post-item[data-post-id='${activePostIdForComments}']`);
            if (postInFeed) {
                const span = postInFeed.querySelector('.comment-count-span');
                let current = parseInt(span.textContent) || 0;
                span.textContent = `${current + 1} Comments`;
            }

        } catch (err) {
            showToast('Failed to post comment.', 'error');
        } finally {
            btn.disabled = false;
            btn.textContent = originalText;
        }
    });

    
    // Khi click vào trong danh sách comment
    commentsList.addEventListener('click', async (e) => {
        const target = e.target;
        const commentItem = target.closest('.comment-item');
        if (!commentItem) return;

        // ✅ 1. Mở ô trả lời (reply form)
        if (target.classList.contains('reply-btn')) {
            const replyFormContainer = commentItem.querySelector('.reply-form-container');
            const isVisible = replyFormContainer.style.display === 'block';

            // Đóng tất cả form khác
            document.querySelectorAll('.reply-form-container').forEach(c => c.style.display = 'none');

            // Nếu form này chưa mở → mở và focus input
            if (!isVisible) {
                replyFormContainer.style.display = 'block';
                replyFormContainer.querySelector('input').focus();
            }
        }

        // ✅ 2. Khi click "X replies" → Load replies từ API thay vì thông báo lỗi
        else if (target.classList.contains('view-replies-btn')) {
            const parentCommentId = commentItem.dataset.commentId;
            let repliesList = commentItem.querySelector('.replies-list');

            // Nếu chưa có <ul class="replies-list"> thì tạo mới
            if (!repliesList) {
                repliesList = document.createElement('ul');
                repliesList.className = 'replies-list';
                // Đảm bảo tạo repliesContainer nếu nó chưa tồn tại trong DOM
                const repliesContainerDiv = document.createElement('div');
                repliesContainerDiv.className = 'replies-container';
                repliesContainerDiv.innerHTML = `<button class="view-replies-btn" data-parent-id="${parentCommentId}">Hide replies</button>`; // Tạo lại nút
                repliesContainerDiv.appendChild(repliesList);
                commentItem.querySelector('.comment-content-wrapper').appendChild(repliesContainerDiv);
                
                // Cập nhật lại target để tránh lỗi null
                repliesList = repliesContainerDiv.querySelector('.replies-list');
                target.remove(); // Xóa nút cũ để tránh bị trùng
            }

            // Nếu đang hiển thị → ẩn đi
            if (repliesList.style.display === 'block') {
                repliesList.style.display = 'none';
                target.textContent = `${commentItem.dataset.replyCount} replies`;
                return;
            }

            // ✅ Lần đầu click → Gọi API tải replies thật
            if (repliesList.children.length === 0 || repliesList.children[0].textContent === 'Loading replies...') {
                repliesList.innerHTML = '<li>Loading replies...</li>';
                try {
                    const data = await apiRequest(`/api/comments/${parentCommentId}/replies`);
                    repliesList.innerHTML = '';

                    if (data.replies.length === 0) {
                        repliesList.innerHTML = '<li>No replies yet.</li>';
                    } else {
                        data.replies.forEach(r => {
                            const avatar = r.avatar_url ? `/api/avatars/${r.avatar_url}` : '/macdinh.jpg';

                            const li = document.createElement('li');
                            li.className = 'reply-item';
                            li.innerHTML = `
                                <img src="${avatar}" class="comment-avatar">
                                <div class="comment-content-wrapper">
                                    <div class="comment-body">
                                        <span class="comment-user" data-username="${r.username}">${r.display_name}</span>
                                        <p class="comment-content">${r.content}</p>
                                    </div>
                                    <div class="comment-actions">
                                        <span class="comment-timestamp">${timeAgo(r.created_at)}</span>
                                    </div>
                                </div>
                            `;
                            repliesList.appendChild(li);
                        });
                    }
                } catch (err) {
                    repliesList.innerHTML = '<li>Failed to load replies.</li>';
                }
            }

            // ✅ Hiện replies
            repliesList.style.display = 'block';
            target.textContent = 'Hide replies';
        }
    });


    commentsList.addEventListener('submit', async (e) => {
        if (e.target.classList.contains('reply-form')) {
            e.preventDefault();
            const form = e.target;
            const input = form.querySelector('input');
            const content = input.value.trim();
            const parentComment = form.closest('.comment-item');
            const parentCommentId = parentComment.dataset.commentId;
            if (!content) return;

            try {
                // ✅ Gửi lên server và nhận lại reply mới
                const res = await apiRequest(`/api/posts/${activePostIdForComments}/comment`, {
                    method: 'POST',
                    body: JSON.stringify({ content, parent_comment_id: parentCommentId })
                });

                const r = res.comment;
                input.value = '';
                form.closest('.reply-form-container').style.display = 'none';

                // ✅ Kiểm tra container replies-list, nếu chưa có thì tạo mới
                let repliesContainer = parentComment.querySelector('.replies-list');
                let viewRepliesBtn = parentComment.querySelector('.view-replies-btn');
                
                if (!repliesContainer) {
                    const repliesContainerDiv = document.createElement('div');
                    repliesContainerDiv.className = 'replies-container';
                    viewRepliesBtn = document.createElement('button');
                    viewRepliesBtn.className = 'view-replies-btn';
                    viewRepliesBtn.dataset.parentId = parentCommentId;
                    repliesContainer = document.createElement('ul');
                    repliesContainer.className = 'replies-list';
                    repliesContainer.style.display = 'block';
                    repliesContainerDiv.appendChild(viewRepliesBtn);
                    repliesContainerDiv.appendChild(repliesContainer);
                    parentComment.querySelector('.comment-content-wrapper').appendChild(repliesContainerDiv);
                }

                // ✅ Tạo reply mới DOM
                const li = document.createElement('li');
                li.className = 'reply-item';
                const avatar = r.avatar_url && r.avatar_url !== 'macdinh.jpg'
                    ? `/api/avatars/${r.avatar_url}` : '/macdinh.jpg';

                li.innerHTML = `
                    <img src="${avatar}" class="comment-avatar">
                    <div class="comment-content-wrapper">
                        <div class="comment-body">
                            <span class="comment-user" data-username="${r.username}">${r.display_name}</span>
                            <p class="comment-content">${r.content}</p>
                        </div>
                        <div class="comment-actions">
                            <span class="comment-timestamp">${timeAgo(r.created_at)}</span>
                        </div>
                    </div>
                `;

                // ✅ Chèn reply mới lên đầu danh sách
                repliesContainer.prepend(li);
                repliesContainer.style.display = 'block';


                // ✅ Cập nhật số lượng reply hiển thị (nếu có nút)
                let count = parseInt(parentComment.dataset.replyCount) || 0;
                count++;
                parentComment.dataset.replyCount = count;
                if(viewRepliesBtn) viewRepliesBtn.textContent = 'Hide replies';
                
            } catch (err) {
                showToast('Failed to post reply.', 'error');
            }
        }
    });

    
    document.querySelectorAll('.menu-toggle-btn').forEach(btn => btn.addEventListener('click', () => { sidebar.classList.toggle('open'); sidebarOverlay.classList.toggle('active'); }));
    sidebarOverlay.addEventListener('click', () => { sidebar.classList.remove('open'); sidebarOverlay.classList.remove('active'); });
    [publicRoomList, privateRoomList].forEach(list => list.addEventListener('click', () => { if (window.innerWidth <= 768) { sidebar.classList.remove('open'); sidebarOverlay.classList.remove('active'); } }));
    attachImageBtn.addEventListener('click', () => chatImageInput.click());
    chatImageInput.addEventListener('change', async () => { const file = chatImageInput.files[0]; if (!file || !currentRoomId) return; const formData = new FormData(); formData.append('image', file); try { showToast('Uploading image...', 'info'); const res = await apiRequest('/api/upload/chat-image', { method: 'POST', body: formData }); socket.emit('chat message', { text: messageInput.value.trim(), roomId: currentRoomId, imageUrl: res.imageUrl }); messageInput.value = ''; messageInput.style.height = 'auto'; } catch (err) { showToast(`Upload failed: ${err.message}`, 'error'); } finally { chatImageInput.value = ''; } });
    
    // Xử lý nút Message và Block/Unblock trên modal profile
    // THAY THẾ: Cập nhật logic xử lý nút Block/Unblock
    profileModalFooter.addEventListener('click', async (e) => { 
        if (e.target.id === 'message-user-btn') { 
            const partnerId = e.target.dataset.userId; 
            try { 
                const data = await apiRequest('/api/conversations/start', { method: 'POST', body: JSON.stringify({ partnerId: partnerId }) }); 
                closeModal('profile-view-modal'); 
                if (data.isRequest) { 
                    showToast(data.message, 'success'); 
                } else { 
                    await fetchAndRenderRooms(); 
                    switchView('chat'); 
                    selectRoom(data.roomId); 
                } 
            } catch (err) { 
                showToast(`${err.message}`, 'error'); 
            } 
        } else if (e.target.id === 'block-user-btn') {
            const action = e.target.dataset.action;
            const userId = e.target.dataset.userId;
            const username = e.target.dataset.username;

            const confirmed = await showConfirmation(
                `${action === 'block' ? 'Block' : 'Unblock'} User`,
                `Are you sure you want to ${action} this user?`,
                { danger: action === 'block' }
            );

            if (confirmed) {
                try {
                    const endpoint = action === 'block' ? '/api/users/block' : '/api/users/unblock';
                    const body = action === 'block' ? { userIdToBlock: userId } : { userIdToUnblock: userId };
                    await apiRequest(endpoint, { method: 'POST', body: JSON.stringify(body) });
                    
                    showToast(`User ${action}ed successfully.`, 'success');
                    
                    // MỚI: Tải lại trạng thái và cập nhật UI ngay lập tức
                    const statusData = await apiRequest(`/api/friends/status/${username}`);
                    updateProfileActions(username, userId, statusData);
                    
                    // Tải lại các view bị ảnh hưởng
                    if (currentView === 'friends') loadFriendsList();
                    if (currentView === 'feed') loadPosts(true);
                    if (currentView === 'search') executeSearch(true);
                    
                    // Nếu là block, đóng modal sau khi cập nhật
                    if (action === 'block') closeModal('profile-view-modal'); 

                } catch (err) {
                    showToast(`Failed to ${action} user.`, 'error');
                }
            }
        }
    });

    messageRequestList.addEventListener('click', async (e) => { if (e.target.matches('button')) { const requestId = e.target.dataset.id; const action = e.target.dataset.action; e.target.disabled = true; try { if (action === 'accept') { const data = await apiRequest('/api/message-requests/respond', { method: 'POST', body: JSON.stringify({ requestId, action }) }); await fetchAndRenderRooms(); await fetchAndRenderMessageRequests(); selectRoom(data.roomId); } else if (action === 'decline') { await apiRequest('/api/message-requests/respond', { method: 'POST', body: JSON.stringify({ requestId, action }) }); e.target.closest('li').remove(); if (messageRequestList.children.length === 0) messageRequestsContainer.style.display = 'none'; } } catch (err) { showToast('Action failed.', 'error'); e.target.disabled = false; } } });

    // --- INITIAL LOAD ---
    const token = localStorage.getItem('token');
    const user = JSON.parse(localStorage.getItem('user'));
    const match = window.location.pathname.match(/^\/join\/([a-fA-F0-9-]+)$/);
    if (match) { localStorage.setItem('pendingInvite', match[1]); window.history.pushState({}, '', '/'); }
    if (token && user) initChat(token, user); 
    else { authContainer.style.display = 'block'; if (localStorage.getItem('pendingInvite')) showAuthMessage('Please log in or register to join the room.', 'login'); }
});