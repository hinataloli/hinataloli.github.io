require('dotenv').config();
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const pool = require('./db');
const bcrypt = require('bcrypt');
const path = require('path');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const PORT = 5555;
const saltRounds = 10;
const JWT_SECRET = process.env.JWT_SECRET;
const userSockets = {}; // { userId: socketId }
const onlineUsers = new Set(); // Theo dõi người dùng online

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- Cấu hình Multer ---
const AVATAR_PATH = path.join(__dirname, 'uploads/avatars');
const CHAT_IMAGE_PATH = path.join(__dirname, 'uploads/chat_images');
const POST_IMAGE_PATH = path.join(__dirname, 'uploads/post_images');
if (!fs.existsSync(AVATAR_PATH)) fs.mkdirSync(AVATAR_PATH, { recursive: true });
if (!fs.existsSync(CHAT_IMAGE_PATH)) fs.mkdirSync(CHAT_IMAGE_PATH, { recursive: true });
if (!fs.existsSync(POST_IMAGE_PATH)) fs.mkdirSync(POST_IMAGE_PATH, { recursive: true });

const createMulterStorage = (destination) => multer.diskStorage({
    destination: (req, file, cb) => cb(null, destination),
    filename: (req, file, cb) => cb(null, `${uuidv4()}${path.extname(file.originalname)}`)
});

const avatarUpload = multer({ storage: createMulterStorage(AVATAR_PATH) });
const chatImageUpload = multer({ storage: createMulterStorage(CHAT_IMAGE_PATH) });
const postImageUpload = multer({ storage: createMulterStorage(POST_IMAGE_PATH) });

// --- Middlewares ---
function authenticateToken(req, res, next) {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) return res.sendStatus(401);
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
}

async function isRoomAdmin(req, res, next) {
    try {
        const { roomId } = req.params;
        const [room] = await pool.execute('SELECT type, creator_id FROM rooms WHERE id = ?', [roomId]);
        if (room.length === 0) return res.status(404).json({ message: 'Room not found.' });
        // SỬA: Cho phép Public room có admin quản lý
        if (room[0].type !== 'private' && room[0].type !== 'public') return res.status(403).json({ message: 'This feature is for group rooms only.' });
        
        let isAdmin = false;
        if(room[0].type === 'private') {
            const [rows] = await pool.execute('SELECT role FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, req.user.id]);
            isAdmin = (rows.length > 0 && rows[0].role === 'admin');
        } else if (room[0].type === 'public') {
            // Chỉ creator mới là admin
            isAdmin = room[0].creator_id === req.user.id;
        }

        if (!isAdmin) return res.status(403).json({ message: 'Forbidden: You are not an admin of this room.' });
        next();
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
}

// --- API Routes ---

// --- Logic và API cho Thông báo ---
async function createNotification(recipientId, senderId, type, relatedId) {
    if (recipientId == senderId) return; // Không tự gửi thông báo cho chính mình
    try {
        await pool.execute(
            'INSERT INTO notifications (recipient_id, sender_id, type, related_id) VALUES (?, ?, ?, ?)',
            [recipientId, senderId, type, relatedId]
        );
        const recipientSocketId = userSockets[recipientId];
        if (recipientSocketId) {
            const [[sender]] = await pool.execute('SELECT display_name, avatar_url FROM users WHERE id = ?', [senderId]);
            io.to(recipientSocketId).emit('new_notification', {
                sender_name: sender.display_name,
                sender_avatar: sender.avatar_url,
                type: type,
                related_id: relatedId
            });
        }
    } catch (err) {
        console.error(`Failed to create notification: ${err.message}`);
    }
}

app.get('/api/notifications', authenticateToken, async (req, res) => {
    try {
        const sql = `
            SELECT n.id, n.type, n.related_id, n.is_read, n.created_at,
                   u.display_name as sender_name, u.avatar_url as sender_avatar
            FROM notifications n
            JOIN users u ON n.sender_id = u.id
            WHERE n.recipient_id = ?
            ORDER BY n.created_at DESC
            LIMIT 20
        `;
        const [notifications] = await pool.execute(sql, [req.user.id]);
        res.json(notifications);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
});

app.post('/api/notifications/mark-read', authenticateToken, async (req, res) => {
    try {
        await pool.execute('UPDATE notifications SET is_read = TRUE WHERE recipient_id = ?', [req.user.id]);
        res.status(204).send();
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
});


// --- Auth API ---
app.post('/register', avatarUpload.single('avatar'), async (req, res) => {
    const { username, password, display_name } = req.body;
    const avatar_url = req.file ? req.file.filename : 'macdinh.jpg';
    if (!username || !password) return res.status(400).json({ message: 'Username and password are required.' });
    try {
        const [existing] = await pool.execute('SELECT id FROM users WHERE username = ?', [username]);
        if (existing.length > 0) return res.status(409).json({ message: 'Username already exists.' });
        const hash = await bcrypt.hash(password, saltRounds);
        await pool.execute('INSERT INTO users (username, password_hash, avatar_url, display_name) VALUES (?, ?, ?, ?)', [username, hash, avatar_url, display_name || username]);
        res.status(201).json({ message: 'Registration successful. Please log in.' });
    } catch (err) { console.error("Register Error:", err); res.status(500).json({ message: 'Server error during registration.' }); }
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const [users] = await pool.execute('SELECT id, password_hash, avatar_url, is_admin, display_name, created_at, allow_stranger_messages FROM users WHERE username = ?', [username]);
        if (users.length === 0) return res.status(401).json({ message: 'Invalid credentials.' });
        const user = users[0];
        const match = await bcrypt.compare(password, user.password_hash);
        if (match) {
            const userPayload = { id: user.id, username, display_name: user.display_name, avatar_url: user.avatar_url, is_admin: !!user.is_admin, created_at: user.created_at, allow_stranger_messages: !!user.allow_stranger_messages };
            const accessToken = jwt.sign(userPayload, JWT_SECRET, { expiresIn: '1d' });
            res.json({ accessToken, user: userPayload });
        } else { res.status(401).json({ message: 'Invalid credentials.' }); }
    } catch (err) { console.error("Login Error:", err); res.status(500).json({ message: 'Server error during login.' }); }
});

// --- User & Uploads API ---
app.post('/api/upload-avatar', authenticateToken, avatarUpload.single('avatar'), async (req, res) => {
    if (!req.file) return res.status(400).json({ message: 'No file uploaded.' });
    try {
        await pool.execute('UPDATE users SET avatar_url = ? WHERE id = ?', [req.file.filename, req.user.id]);
        res.json({ success: true, avatar_url: req.file.filename });
    } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.post('/api/upload/chat-image', authenticateToken, chatImageUpload.single('image'), async (req, res) => {
    if (!req.file) return res.status(400).json({ message: 'No image file uploaded.' });
    res.json({ success: true, imageUrl: req.file.filename });
});

app.get('/api/avatars/:filename', (req, res) => {
    const filePath = path.join(AVATAR_PATH, req.params.filename);
    fs.existsSync(filePath) ? res.sendFile(filePath) : res.sendFile(path.join(__dirname, 'public/macdinh.jpg'));
});

app.get('/api/images/:filename', (req, res) => {
    const filePath = path.join(CHAT_IMAGE_PATH, req.params.filename);
    fs.existsSync(filePath) ? res.sendFile(filePath) : res.status(404).send('Not Found');
});

app.get('/api/posts/images/:filename', (req, res) => {
    const filePath = path.join(POST_IMAGE_PATH, req.params.filename);
    fs.existsSync(filePath) ? res.sendFile(filePath) : res.status(404).send('Not Found');
});

app.get('/api/users/search', authenticateToken, async (req, res) => {
    const { username } = req.query;
    if (!username) return res.status(400).json({ message: 'Username query is required.' });
    try {
        const sql = `
            SELECT u.id, u.username, u.display_name, u.avatar_url 
            FROM users u
            LEFT JOIN blocks b ON (b.blocker_id = u.id AND b.blocked_id = ?) OR (b.blocker_id = ? AND b.blocked_id = u.id)
            WHERE (u.username LIKE ? OR u.display_name LIKE ?) 
            AND u.id != ? 
            AND b.id IS NULL
            LIMIT 5
        `;
        const [users] = await pool.execute(sql, [req.user.id, req.user.id, `%${username}%`, `%${username}%`, req.user.id]);
        res.json(users);
    } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

// THAY THẾ: /api/users/:username để trả về thêm thông tin
app.get('/api/users/:username', authenticateToken, async (req, res) => {
    try {
        const { username } = req.params;
        const [users] = await pool.execute(
            'SELECT id, username, display_name, avatar_url, created_at, allow_stranger_messages, display_name_last_changed FROM users WHERE username = ?',
            [username]
        );
        if (users.length === 0) return res.status(404).json({ message: 'User not found.' });
        res.json(users[0]);
    } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

// THAY THẾ: /api/user/profile để xử lý đổi tên, mật khẩu, cài đặt
app.put('/api/user/profile', authenticateToken, async (req, res) => {
    const { display_name, current_password, new_password, confirm_new_password, allow_stranger_messages } = req.body;
    const { id, is_admin } = req.user;
    try {
        const [[currentUser]] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
        if (!currentUser) return res.status(404).json({ message: 'User not found' });
        let updateFields = [];
        let updateValues = [];
        if (display_name && display_name !== currentUser.display_name) {
            const sevenDays = 7 * 24 * 60 * 60 * 1000;
            if (currentUser.display_name_last_changed && (new Date() - new Date(currentUser.display_name_last_changed)) < sevenDays && !is_admin) {
                const nextChangeDate = new Date(new Date(currentUser.display_name_last_changed).getTime() + sevenDays);
                return res.status(403).json({ message: `You can change your name again after ${nextChangeDate.toLocaleDateString()}.` });
            }
            updateFields.push('display_name = ?', 'display_name_last_changed = NOW()');
            updateValues.push(display_name);
        }
        if (new_password) {
            if (!current_password) return res.status(400).json({ message: 'Current password is required to set a new one.' });
            const match = await bcrypt.compare(current_password, currentUser.password_hash);
            if (!match) return res.status(403).json({ message: 'Incorrect current password.' });
            if (new_password !== confirm_new_password) return res.status(400).json({ message: 'New passwords do not match.' });
            const hash = await bcrypt.hash(new_password, saltRounds);
            updateFields.push('password_hash = ?');
            updateValues.push(hash);
        }
        if (typeof allow_stranger_messages === 'boolean') {
            updateFields.push('allow_stranger_messages = ?');
            updateValues.push(allow_stranger_messages);
        }
        if (updateFields.length > 0) {
            updateValues.push(id);
            await pool.execute(`UPDATE users SET ${updateFields.join(', ')} WHERE id = ?`, updateValues);
        }
        const [[updatedUser]] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
        const userPayload = { id: updatedUser.id, username: updatedUser.username, display_name: updatedUser.display_name, avatar_url: updatedUser.avatar_url, is_admin: !!updatedUser.is_admin, created_at: updatedUser.created_at, allow_stranger_messages: !!updatedUser.allow_stranger_messages };
        const accessToken = jwt.sign(userPayload, JWT_SECRET, { expiresIn: '1d' });
        res.json({ message: 'Profile updated successfully.', accessToken, user: userPayload });
    } catch (err) { res.status(500).json({ message: 'Server error while updating profile.' }); }
});

// --- FRIENDSHIP & BLOCK API ---

// MỚI: API chặn và bỏ chặn
app.post('/api/users/block', authenticateToken, async (req, res) => {
    const { userIdToBlock } = req.body;
    const blockerId = req.user.id;
    if (userIdToBlock == blockerId) return res.status(400).json({ message: "You cannot block yourself." });
    try {
        const userOne = Math.min(blockerId, userIdToBlock);
        const userTwo = Math.max(blockerId, userIdToBlock);
        await pool.execute('DELETE FROM friends WHERE user_one_id = ? AND user_two_id = ?', [userOne, userTwo]);
        await pool.execute('INSERT IGNORE INTO blocks (blocker_id, blocked_id) VALUES (?, ?)', [blockerId, userIdToBlock]);
        res.status(201).json({ message: 'User blocked.' });
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/users/unblock', authenticateToken, async (req, res) => {
    const { userIdToUnblock } = req.body;
    const blockerId = req.user.id;
    try {
        await pool.execute('DELETE FROM blocks WHERE blocker_id = ? AND blocked_id = ?', [blockerId, userIdToUnblock]);
        res.status(200).json({ message: 'User unblocked.' });
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

// MỚI: API lấy danh sách bạn bè online
app.get('/api/friends/online', authenticateToken, async (req, res) => {
    try {
        const [friends] = await pool.execute( `SELECT u.id FROM users u JOIN friends f ON (u.id = f.user_one_id OR u.id = f.user_two_id) WHERE (f.user_one_id = ? OR f.user_two_id = ?) AND f.status = 'accepted' AND u.id != ?`, [req.user.id, req.user.id, req.user.id] );
        const onlineFriendIds = friends.filter(friend => onlineUsers.has(friend.id)).map(friend => friend.id);
        res.json(onlineFriendIds);
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

// THAY THẾ: /api/friends/status/:otherUsername để kiểm tra cả trạng thái block
app.get('/api/friends/status/:otherUsername', authenticateToken, async (req, res) => {
    const { id: currentUserId } = req.user;
    const { otherUsername } = req.params;
    try {
        const [[otherUser]] = await pool.execute('SELECT id FROM users WHERE username = ?', [otherUsername]);
        if (!otherUser) return res.status(404).json({ message: 'User not found' });
        const otherUserId = otherUser.id;
        const [[friendship]] = await pool.execute(`SELECT status, action_user_id FROM friends WHERE (user_one_id = ? AND user_two_id = ?) OR (user_one_id = ? AND user_two_id = ?)`, [currentUserId, otherUserId, otherUserId, currentUserId]);
        const [[blockStatus]] = await pool.execute('SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)', [currentUserId, otherUserId, otherUserId, currentUserId]);
        res.json({
            friendship: friendship ? { status: friendship.status, isRequester: friendship.action_user_id === currentUserId } : { status: 'none' },
            isBlocked: !!blockStatus
        });
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/friends/request', authenticateToken, async (req, res) => {
    const { id: requesterId, display_name: requesterName, avatar_url: requesterAvatar } = req.user;
    const { recipientId } = req.body;
    if (requesterId == recipientId) return res.status(400).json({ message: 'You cannot add yourself.'});
    
    try {
        const [[blockStatus]] = await pool.execute('SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)', [requesterId, recipientId, recipientId, requesterId]);
        if(blockStatus) return res.status(403).json({ message: "Cannot send request due to a block." });

        const userOne = Math.min(requesterId, recipientId);
        const userTwo = Math.max(requesterId, recipientId);

        await pool.execute(
            `INSERT INTO friends (user_one_id, user_two_id, action_user_id, status) VALUES (?, ?, ?, 'pending')
             ON DUPLICATE KEY UPDATE status = VALUES(status), action_user_id = VALUES(action_user_id)`,
            [userOne, userTwo, requesterId]
        );
        
        const recipientSocketId = userSockets[recipientId];
        if (recipientSocketId) {
            io.to(recipientSocketId).emit('new_friend_request', {
                id: requesterId,
                display_name: requesterName,
                avatar_url: requesterAvatar
            });
        }

        res.status(201).json({ message: 'Friend request sent.'});
    } catch(err) {
        console.error("Friend Request Error:", err);
        res.status(500).json({ message: 'Server error sending request.'});
    }
});

app.post('/api/friends/accept', authenticateToken, async (req, res) => {
    const { id: currentUserId } = req.user;
    const { requesterId } = req.body;
    const userOne = Math.min(currentUserId, requesterId);
    const userTwo = Math.max(currentUserId, requesterId);
    try {
        const [updateResult] = await pool.execute(
            `UPDATE friends SET status = 'accepted' WHERE user_one_id = ? AND user_two_id = ? AND action_user_id = ? AND status = 'pending'`,
            [userOne, userTwo, requesterId]
        );
        
        if (updateResult.affectedRows > 0) {
            createNotification(requesterId, currentUserId, 'friend_accept', currentUserId);
        }

        const requesterSocketId = userSockets[requesterId];
        if (requesterSocketId) io.to(requesterSocketId).emit('friend_list_updated');
        const currentUserSocketId = userSockets[currentUserId];
        if (currentUserSocketId) io.to(currentUserSocketId).emit('friend_list_updated');
        
        res.json({ message: 'Friend request accepted.' });
    } catch (err) {
        res.status(500).json({ message: 'Server error accepting request.' });
    }
});

app.post('/api/friends/remove', authenticateToken, async (req, res) => {
    const { id: currentUserId } = req.user;
    const { friendId } = req.body;
    const userOne = Math.min(currentUserId, friendId);
    const userTwo = Math.max(currentUserId, friendId);
    try {
        await pool.execute('DELETE FROM friends WHERE user_one_id = ? AND user_two_id = ?', [userOne, userTwo]);
        
        const friendSocketId = userSockets[friendId];
        if (friendSocketId) io.to(friendSocketId).emit('friend_list_updated');
        const currentUserSocketId = userSockets[currentUserId];
        if (currentUserSocketId) io.to(currentUserSocketId).emit('friend_list_updated');

        res.json({ message: 'Friend removed successfully.' });
    } catch (err) {
        res.status(500).json({ message: 'Server error removing friend.' });
    }
});

// Cập nhật API để lọc người dùng bị chặn
app.get('/api/friends/requests', authenticateToken, async (req, res) => {
    const currentUserId = req.user.id;
    try {
        const sql = `
            SELECT u.id, u.username, u.display_name, u.avatar_url
            FROM friends f
            JOIN users u ON f.action_user_id = u.id
            LEFT JOIN blocks b ON (b.blocker_id = u.id AND b.blocked_id = ?) OR (b.blocker_id = ? AND b.blocked_id = u.id)
            WHERE 
                ((f.user_one_id = ? AND f.action_user_id != ?) OR (f.user_two_id = ? AND f.action_user_id != ?))
                AND f.status = 'pending'
                AND b.id IS NULL
        `;
        const [requests] = await pool.execute(sql, [currentUserId, currentUserId, currentUserId, currentUserId, currentUserId, currentUserId]);
        res.json(requests);
    } catch (err) {
        console.error("Get Friend Requests Error:", err);
        res.status(500).json({ message: 'Server error' });
    }
});

// Cập nhật API để lọc người dùng bị chặn
app.get('/api/friends/list', authenticateToken, async (req, res) => {
    const currentUserId = req.user.id;
    try {
        const sql = `
            SELECT u.id, u.username, u.display_name, u.avatar_url
            FROM users u
            JOIN friends f ON (u.id = f.user_one_id OR u.id = f.user_two_id)
            LEFT JOIN blocks b ON (b.blocker_id = u.id AND b.blocked_id = ?) OR (b.blocker_id = ? AND b.blocked_id = u.id)
            WHERE 
                (f.user_one_id = ? OR f.user_two_id = ?)
                AND f.status = 'accepted'
                AND u.id != ?
                AND b.id IS NULL
        `;
        const [friends] = await pool.execute(sql, [currentUserId, currentUserId, currentUserId, currentUserId, currentUserId]);
        res.json(friends);
    } catch (err) {
        console.error("Get Friends List Error:", err);
        res.status(500).json({ message: 'Server error' });
    }
});


// --- SEARCH API ---
// Cập nhật API để lọc người dùng và bài viết bị chặn
app.get('/api/search', authenticateToken, async (req, res) => {
    const { q, page = 0, limit = 10 } = req.query;
    const currentUserId = req.user.id;
    if (!q) {
        return res.status(400).json({ message: 'Query parameter "q" is required.' });
    }

    try {
        const searchQuery = `%${q}%`;
        const offset = parseInt(page, 10) * parseInt(limit, 10);

        const userSql = `
            SELECT id, username, display_name, avatar_url 
            FROM users u
            LEFT JOIN blocks b ON (b.blocker_id = u.id AND b.blocked_id = ?) OR (b.blocker_id = ? AND b.blocked_id = u.id)
            WHERE (username LIKE ? OR display_name LIKE ?) AND id != ? AND b.id IS NULL
            LIMIT 5
        `;
        const [users] = await pool.execute(userSql, [currentUserId, currentUserId, searchQuery, searchQuery, currentUserId]);

        const postSql = `
            SELECT 
                p.id, p.content, p.image_url, p.created_at, p.privacy,
                u.username, u.display_name, u.avatar_url,
                (SELECT COUNT(*) FROM likes WHERE post_id = p.id) AS like_count,
                (SELECT COUNT(*) FROM comments WHERE post_id = p.id) AS comment_count,
                (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) > 0 AS liked_by_user
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE 
                p.content LIKE ? AND (
                    p.user_id = ? OR 
                    p.privacy = 'public' OR
                    (
                        p.privacy = 'friends' AND EXISTS (
                            SELECT 1 FROM friends f
                            WHERE f.status = 'accepted' AND
                                  ((f.user_one_id = p.user_id AND f.user_two_id = ?) OR
                                   (f.user_one_id = ? AND f.user_two_id = p.user_id))
                        )
                    )
                )
                AND NOT EXISTS (
                    SELECT 1 FROM blocks b WHERE (b.blocker_id = p.user_id AND b.blocked_id = ?) OR (b.blocker_id = ? AND b.blocked_id = p.user_id)
                )
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        `;
        const [posts] = await pool.execute(postSql, [currentUserId, searchQuery, currentUserId, currentUserId, currentUserId, currentUserId, currentUserId, String(limit), String(offset)]);
        
        res.json({
            query: q,
            users: users,
            posts: {
                results: posts,
                hasNext: posts.length === parseInt(limit, 10)
            }
        });

    } catch (err) {
        console.error("Search Error:", err);
        res.status(500).json({ message: 'An error occurred during search.' });
    }
});


// --- FEED API ---
// Cập nhật API để lọc bài viết từ người dùng bị chặn
app.get('/api/posts', authenticateToken, async (req, res) => {
    const page = parseInt(req.query.page, 10) || 0;
    const limit = 10;
    const offset = page * limit;
    const currentUserId = req.user.id;

    try {
        const sql = `
            SELECT 
                p.id, p.content, p.image_url, p.created_at, p.privacy,
                u.username, u.display_name, u.avatar_url,
                (SELECT COUNT(*) FROM likes WHERE post_id = p.id) AS like_count,
                (SELECT COUNT(*) FROM comments WHERE post_id = p.id) AS comment_count,
                (SELECT COUNT(*) FROM likes WHERE post_id = p.id AND user_id = ?) > 0 AS liked_by_user
            FROM posts p
            JOIN users u ON p.user_id = u.id
            WHERE (
                p.user_id = ? OR 
                p.privacy = 'public' OR 
                (
                    p.privacy = 'friends' AND EXISTS (
                        SELECT 1 FROM friends f
                        WHERE f.status = 'accepted' AND
                              ((f.user_one_id = p.user_id AND f.user_two_id = ?) OR
                               (f.user_one_id = ? AND f.user_two_id = p.user_id))
                    )
                )
            ) AND NOT EXISTS (
                SELECT 1 FROM blocks b WHERE (b.blocker_id = p.user_id AND b.blocked_id = ?) OR (b.blocker_id = ? AND b.blocked_id = p.user_id)
            )
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        `;
        const [posts] = await pool.execute(sql, [currentUserId, currentUserId, currentUserId, currentUserId, currentUserId, currentUserId, String(limit), String(offset)]);
        res.json({ posts, hasNext: posts.length === limit });
    } catch (err) {
        console.error("Get Posts Error:", err);
        res.status(500).json({ message: 'Failed to load posts.' });
    }
});

app.post('/api/posts', authenticateToken, postImageUpload.single('image'), async (req, res) => {
    const { content, privacy } = req.body;
    const image_url = req.file ? req.file.filename : null;
    const user_id = req.user.id;

    if (!content && !image_url) {
        return res.status(400).json({ message: 'Post cannot be empty.' });
    }
    
    const validPrivacy = ['public', 'friends', 'private'].includes(privacy) ? privacy : 'public';

    try {
        const [result] = await pool.execute(
            'INSERT INTO posts (user_id, content, image_url, privacy) VALUES (?, ?, ?, ?)',
            [user_id, content, image_url, validPrivacy]
        );
        res.status(201).json({ message: 'Post created successfully', postId: result.insertId });
    } catch (err) {
        console.error("Create Post Error:", err);
        res.status(500).json({ message: 'Server error while creating post.' });
    }
});

// THAY THẾ: Logic like post đã được cập nhật để kiểm tra block
app.post('/api/posts/:postId/like', authenticateToken, async (req, res) => {
    const { postId } = req.params;
    const user_id = req.user.id;

    try {
        const [[postOwner]] = await pool.execute('SELECT user_id FROM posts WHERE id = ?', [postId]);
        if (!postOwner) return res.status(404).json({ message: 'Post not found.' });

        // MỚI: Kiểm tra trạng thái block giữa người dùng và chủ bài viết
        const blockedCheck = await pool.execute(
            'SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)',
            [user_id, postOwner.user_id, postOwner.user_id, user_id]
        );
        if (blockedCheck[0].length > 0) {
            return res.status(403).json({ message: "Cannot like: Block status detected." });
        }
        
        const [existing] = await pool.execute(
            'SELECT id FROM likes WHERE user_id = ? AND post_id = ?',
            [user_id, postId]
        );

        if (existing.length > 0) {
            await pool.execute('DELETE FROM likes WHERE id = ?', [existing[0].id]);
            res.json({ liked: false, message: 'Post unliked.' });
        } else {
            await pool.execute('INSERT INTO likes (user_id, post_id) VALUES (?, ?)', [user_id, postId]);
            
            if (postOwner) {
                const [[existingNotification]] = await pool.execute(
                    'SELECT id FROM notifications WHERE sender_id = ? AND type = "like" AND related_id = ?',
                    [user_id, postId]
                );

                if (!existingNotification) {
                    createNotification(postOwner.user_id, user_id, 'like', postId);
                }
            }

            res.json({ liked: true, message: 'Post liked.' });
        }
    } catch (err) {
        console.error("Like Post Error:", err);
        res.status(500).json({ message: 'Server error.' });
    }
});

// THAY THẾ: Logic comment post đã được cập nhật để kiểm tra block
app.post('/api/posts/:postId/comment', authenticateToken, async (req, res) => {
    const { postId } = req.params;
    const { content, parent_comment_id } = req.body;
    const user_id = req.user.id;

    if (!content || content.trim() === '') {
        return res.status(400).json({ message: 'Comment cannot be empty.' });
    }

    try {
        const [[postOwner]] = await pool.execute('SELECT user_id FROM posts WHERE id = ?', [postId]);
        if (!postOwner) return res.status(404).json({ message: 'Post not found.' });

        // MỚI: Kiểm tra trạng thái block giữa người dùng và chủ bài viết
        const blockedCheck = await pool.execute(
            'SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)',
            [user_id, postOwner.user_id, postOwner.user_id, user_id]
        );
        if (blockedCheck[0].length > 0) {
            return res.status(403).json({ message: "Cannot comment: Block status detected." });
        }
        
        const [result] = await pool.execute(
            `INSERT INTO comments (user_id, post_id, content, parent_comment_id)
             VALUES (?, ?, ?, ?)`,
            [user_id, postId, content, parent_comment_id || null]
        );

        // ✅ Lấy lại dữ liệu comment vừa lưu từ DB
        const [[newComment]] = await pool.execute(`
            SELECT c.id, c.content, c.created_at,
                   c.parent_comment_id,
                   u.username, u.display_name, u.avatar_url
            FROM comments c
            JOIN users u ON c.user_id = u.id
            WHERE c.id = ?`, [result.insertId]);

        res.status(201).json({ message: 'Comment added.', comment: newComment });
    } catch (err) {
        console.error("Add Comment Error:", err);
        res.status(500).json({ message: 'Server error.' });
    }
});


// Lấy replies của 1 comment
app.get('/api/comments/:commentId/replies', authenticateToken, async (req, res) => {
    const { commentId } = req.params;
    try {
        const [replies] = await pool.execute(`
            SELECT 
                c.id, c.content, c.created_at,
                u.username, u.display_name, u.avatar_url
            FROM comments c
            JOIN users u ON c.user_id = u.id
            WHERE parent_comment_id = ?
            ORDER BY c.created_at ASC
        `, [commentId]);

        res.json({ replies });
    } catch (err) {
        res.status(500).json({ message: 'Failed to load replies.' });
    }
});


app.delete('/api/posts/:postId', authenticateToken, async (req, res) => {
    const { postId } = req.params;
    const userId = req.user.id;

    try {
        const [[post]] = await pool.execute('SELECT user_id, image_url FROM posts WHERE id = ?', [postId]);

        if (!post) {
            return res.status(404).json({ message: 'Post not found.' });
        }

        if (post.user_id !== userId && !req.user.is_admin) {
            return res.status(403).json({ message: 'Forbidden: You are not authorized to delete this post.' });
        }

        if (post.image_url) {
            const imagePath = path.join(POST_IMAGE_PATH, post.image_url);
            if (fs.existsSync(imagePath)) {
                fs.unlink(imagePath, (err) => {
                    if (err) console.error(`Failed to delete post image ${imagePath}:`, err);
                });
            }
        }

        await pool.execute('DELETE FROM posts WHERE id = ?', [postId]);

        res.status(200).json({ message: 'Post deleted successfully.' });
    } catch (err) {
        console.error("Delete Post Error:", err);
        res.status(500).json({ message: 'Server error while deleting post.' });
    }
});

app.put('/api/posts/:postId', authenticateToken, async (req, res) => {
    const { postId } = req.params;
    const { content } = req.body;
    const userId = req.user.id;

    if (!content || content.trim() === '') {
        return res.status(400).json({ message: 'Post content cannot be empty.' });
    }

    try {
        const [[post]] = await pool.execute('SELECT user_id FROM posts WHERE id = ?', [postId]);

        if (!post) {
            return res.status(404).json({ message: 'Post not found.' });
        }

        if (post.user_id !== userId && !req.user.is_admin) {
            return res.status(403).json({ message: 'Forbidden: You are not authorized to edit this post.' });
        }

        await pool.execute('UPDATE posts SET content = ? WHERE id = ?', [content, postId]);

        res.status(200).json({ message: 'Post updated successfully.' });
    } catch (err) {
        console.error("Update Post Error:", err);
        res.status(500).json({ message: 'Server error while updating post.' });
    }
});


// --- ROOMS & CHAT API ---

// ===== BẮT ĐẦU THAY THẾ app.get('/api/rooms') =====
app.get('/api/rooms', authenticateToken, async (req, res) => {
    const currentUserId = req.user.id;
    try {
        const sql = `
            -- Lấy các phòng group (public và private)
            (SELECT 
                r.id, r.name, r.type, r.creator_id, r.invite_link_id,
                NULL as partner_avatar,
                NULL as partner_id
            FROM rooms r
            LEFT JOIN room_members rm ON r.id = rm.room_id
            WHERE 
                (r.type = 'public' AND rm.user_id = ? AND rm.status = 'approved') OR
                (rm.user_id = ? AND rm.status = 'approved' AND r.type = 'private')
            )
            UNION
            -- Lấy các phòng chat 1-1 (direct) và tìm tên + avatar của người còn lại
            (SELECT 
                r.id,
                -- Lấy display_name của người còn lại trong phòng chat 1-1
                (SELECT u.display_name FROM users u JOIN room_members rm_partner ON u.id = rm_partner.user_id WHERE rm_partner.room_id = r.id AND rm_partner.user_id != ?) as name,
                r.type, 
                r.creator_id, 
                r.invite_link_id,
                -- Lấy avatar của người còn lại
                (SELECT u.avatar_url FROM users u JOIN room_members rm_partner ON u.id = rm_partner.user_id WHERE rm_partner.room_id = r.id AND rm_partner.user_id != ?) as partner_avatar,
                -- Lấy ID của người còn lại để hiển thị online indicator
                (SELECT u.id FROM users u JOIN room_members rm_partner ON u.id = rm_partner.user_id WHERE rm_partner.room_id = r.id AND rm_partner.user_id != ?) as partner_id
            FROM rooms r
            JOIN room_members rm ON r.id = rm.room_id
            WHERE 
                rm.user_id = ? AND r.type = 'direct'
            )
            ORDER BY id DESC
        `;
        const [rooms] = await pool.execute(sql, [
            currentUserId, currentUserId, // public và private rooms
            currentUserId, currentUserId, currentUserId, currentUserId // direct rooms với avatar và partner_id
        ]);
        
        const finalRooms = rooms.filter(room => room.id !== null).map(room => ({
            ...room,
            name: room.name || 'Conversation'
        }));

        res.json(finalRooms);
    } catch (err) {
        console.error("Get Rooms Error:", err);
        res.status(500).json({ message: 'Server error' });
    }
});
// ===== KẾT THÚC THAY THẾ app.get('/api/rooms') =====

app.post('/api/rooms', authenticateToken, async (req, res) => {
    const { name, type } = req.body;
    const { id: creatorId, is_admin } = req.user;
    if (type === 'public' && !is_admin) return res.status(403).json({ message: 'Only admins can create public rooms.' });
    try {
        const inviteLinkId = type === 'private' ? uuidv4() : null;
        const [result] = await pool.execute('INSERT INTO rooms (name, type, creator_id, invite_link_id) VALUES (?, ?, ?, ?)', [name, type, creatorId, inviteLinkId]);
        const newRoomId = result.insertId;
        // Public rooms: creator tự động được approved, role member
        // Private rooms: creator tự động được approved, role admin
        const initialRole = type === 'private' ? 'admin' : 'member';
        await pool.execute('INSERT INTO room_members (room_id, user_id, role, status) VALUES (?, ?, ?, "approved")', [newRoomId, creatorId, initialRole]);
        res.status(201).json({ id: newRoomId, name, type, creator_id: creatorId, invite_link_id: inviteLinkId });
    } catch (err) { res.status(500).json({ message: 'Server error creating room.' }); }
});

app.post('/api/rooms/:roomId/invite', authenticateToken, isRoomAdmin, async (req, res) => {
    try {
        const inviterId = req.user.id;
        const { userIdToInvite } = req.body;
        const { roomId } = req.params;
        await pool.execute(
            `INSERT INTO invitations (room_id, inviter_id, invitee_id, status) VALUES (?, ?, ?, 'pending')
             ON DUPLICATE KEY UPDATE status = 'pending', inviter_id = ?`,
            [roomId, inviterId, userIdToInvite, inviterId]
        );
        res.json({ message: `Invitation sent.` });
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/rooms/join/:inviteLinkId', authenticateToken, async (req, res) => {
    try {
        const [room] = await pool.execute('SELECT id, name, type FROM rooms WHERE invite_link_id = ? AND type = "private"', [req.params.inviteLinkId]);
        if (room.length === 0) return res.status(404).json({ message: 'Invalid or non-private invite link.' });
        await pool.execute('INSERT INTO room_members (room_id, user_id, status) VALUES (?, ?, "pending") ON DUPLICATE KEY UPDATE status="pending"', [room[0].id, req.user.id]);
        const [admins] = await pool.execute('SELECT user_id FROM room_members WHERE room_id = ? AND role = "admin"', [room[0].id]);
        admins.forEach(admin => {
            const adminSocketId = userSockets[admin.user_id];
            if (adminSocketId) {
                io.to(adminSocketId).emit('new_pending_member', { roomId: room[0].id, roomName: room[0].name });
            }
        });
        res.json({ message: 'Your request to join has been sent and is awaiting approval.', room: room[0] });
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

app.get('/api/invitations', authenticateToken, async (req, res) => {
    try {
        const [invitations] = await pool.execute(`SELECT i.id, r.name as room_name, u.display_name as inviter_name FROM invitations i JOIN rooms r ON i.room_id = r.id JOIN users u ON i.inviter_id = u.id WHERE i.invitee_id = ? AND i.status = 'pending'`, [req.user.id]);
        res.json(invitations);
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/invitations/:invitationId/accept', authenticateToken, async (req, res) => {
    try {
        const [invitation] = await pool.execute('SELECT * FROM invitations WHERE id = ? AND invitee_id = ?', [req.params.invitationId, req.user.id]);
        if (invitation.length === 0) return res.status(404).json({ message: 'Invitation not found.' });
        const roomId = invitation[0].room_id;
        // Mặc định role là member khi accept invite
        await pool.execute('INSERT INTO room_members (room_id, user_id, role, status) VALUES (?, ?, "member", "approved") ON DUPLICATE KEY UPDATE status="approved"', [roomId, req.user.id]);
        await pool.execute('UPDATE invitations SET status = "accepted" WHERE id = ?', [req.params.invitationId]);
        const socketId = userSockets[req.user.id];
        if(socketId) io.to(socketId).emit('room_list_updated');
        io.to(String(roomId)).emit('member_list_updated', { roomId });
        res.json({ message: 'Invitation accepted.' });
    } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.get('/api/rooms/:roomId/members', authenticateToken, async (req, res) => {
    const { roomId } = req.params;
    const currentUserId = req.user.id;
    try {
        const [room] = await pool.execute('SELECT type FROM rooms WHERE id = ?', [roomId]);
        if (room.length === 0) return res.status(404).json({ message: 'Room not found.' });
        
        let isAdmin = false;
        if(room[0].type !== 'direct') {
             const [memberStatus] = await pool.execute('SELECT role FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, currentUserId]);
             isAdmin = (memberStatus.length > 0 && memberStatus[0].role === 'admin');
        } else {
            // Cho phép xem member list của DM
            const [memberStatus] = await pool.execute('SELECT 1 FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, currentUserId]);
            if (memberStatus.length === 0) return res.status(403).json({ message: 'Forbidden: You are not a member of this room.' });
        }
        
        const [members] = await pool.execute(`SELECT u.id, u.username, u.display_name, u.avatar_url, rm.role, rm.status FROM room_members rm JOIN users u ON rm.user_id = u.id WHERE rm.room_id = ?`, [roomId]);
        res.json(members);
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/rooms/:roomId/approve', authenticateToken, isRoomAdmin, async (req, res) => {
    const { roomId } = req.params;
    const { userIdToApprove } = req.body;
    try {
        await pool.execute('UPDATE room_members SET status = "approved" WHERE room_id = ? AND user_id = ? AND status = "pending"', [roomId, userIdToApprove]);
        io.to(String(roomId)).emit('member_list_updated', { roomId });
        const targetSocketId = userSockets[userIdToApprove];
        if (targetSocketId) {
            io.to(targetSocketId).emit('room_list_updated');
        }
        res.json({ message: 'Member approved.' });
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/rooms/:roomId/promote', authenticateToken, isRoomAdmin, async (req, res) => {
    try {
        await pool.execute('UPDATE room_members SET role = "admin" WHERE room_id = ? AND user_id = ?', [req.params.roomId, req.body.userIdToPromote]);
        const targetSocketId = userSockets[req.body.userIdToPromote];
        if (targetSocketId) io.to(targetSocketId).emit('role_updated', { roomId: req.params.roomId, newRole: 'admin' });
        io.to(String(req.params.roomId)).emit('member_list_updated', { roomId: req.params.roomId });
        res.json({ message: 'Member promoted to admin.' });
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/rooms/:roomId/demote', authenticateToken, isRoomAdmin, async (req, res) => {
    try {
        const { userIdToDemote } = req.body;
        const { roomId } = req.params;
        const [room] = await pool.execute('SELECT creator_id FROM rooms WHERE id = ?', [roomId]);
        if (room.length > 0 && room[0].creator_id == userIdToDemote) {
            return res.status(403).json({ message: "Cannot demote the original room creator." });
        }
        await pool.execute('UPDATE room_members SET role = "member" WHERE room_id = ? AND user_id = ?', [roomId, userIdToDemote]);
        const targetSocketId = userSockets[userIdToDemote];
        if (targetSocketId) io.to(targetSocketId).emit('role_updated', { roomId: req.params.roomId, newRole: 'member' });
        io.to(String(req.params.roomId)).emit('member_list_updated', { roomId: req.params.roomId });
        res.json({ message: 'Admin demoted to member.' });
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/rooms/:roomId/kick', authenticateToken, isRoomAdmin, async (req, res) => {
    const { roomId } = req.params;
    const { userIdToKick, roomName } = req.body;
    if (userIdToKick == req.user.id) return res.status(400).json({ message: "You cannot kick yourself." });
    try {
        const [[memberToKick]] = await pool.execute('SELECT role FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, userIdToKick]);
        if (memberToKick && memberToKick.role === 'admin') return res.status(403).json({ message: "Admins cannot kick other admins." });
        await pool.execute('DELETE FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, userIdToKick]);
        const kickedSocketId = userSockets[userIdToKick];
        if (kickedSocketId) {
            const kickedSocket = io.sockets.sockets.get(kickedSocketId);
            if (kickedSocket) {
                kickedSocket.leave(String(roomId));
                kickedSocket.emit('kicked', { roomId, roomName });
            }
        }
        io.to(String(roomId)).emit('member_list_updated', { roomId });
        res.json({ message: 'Member has been kicked.' });
    } catch (err) { res.status(500).json({ message: 'Server error' }); }
});

app.post('/api/rooms/:roomId/leave', authenticateToken, async (req, res) => {
    const { roomId } = req.params;
    const { id: userId } = req.user;
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        const [[memberCountResult]] = await connection.execute('SELECT COUNT(*) as count FROM room_members WHERE room_id = ? AND status = "approved"', [roomId]);
        if (memberCountResult.count <= 1) {
            await connection.execute('DELETE FROM rooms WHERE id = ?', [roomId]);
            await connection.commit();
            return res.json({ success: true, roomDeleted: true });
        }
        const [[currentUser]] = await connection.execute('SELECT role FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, userId]);
        const [[{ adminCount }]] = await connection.execute('SELECT COUNT(*) as adminCount FROM room_members WHERE room_id = ? AND role = "admin"', [roomId]);
        await connection.execute('DELETE FROM room_members WHERE room_id = ? AND user_id = ?', [roomId, userId]);
        if (currentUser && currentUser.role === 'admin' && adminCount === 1) {
            const [[oldestMember]] = await connection.execute('SELECT user_id FROM room_members WHERE room_id = ? AND status = "approved" ORDER BY joined_at ASC LIMIT 1', [roomId]);
            if (oldestMember) {
                await connection.execute('UPDATE room_members SET role = "admin" WHERE room_id = ? AND user_id = ?', [roomId, oldestMember.user_id]);
                const targetSocketId = userSockets[oldestMember.user_id];
                if (targetSocketId) io.to(targetSocketId).emit('role_updated', { roomId, newRole: 'admin' });
            }
        }
        io.to(String(roomId)).emit('member_list_updated', { roomId });
        await connection.commit();
        res.json({ success: true, roomDeleted: false });
    } catch (err) { await connection.rollback(); res.status(500).json({ message: 'Server error' }); }
    finally { connection.release(); }
});

// Cập nhật API để lọc tin nhắn từ người bị chặn
app.get('/api/rooms/:roomId/messages', authenticateToken, async (req, res) => {
    const { roomId } = req.params;
    const currentUserId = req.user.id;
    try {
        const [roomResult] = await pool.execute('SELECT type FROM rooms WHERE id = ?', [roomId]);
        let isMember = false;
        if (roomResult.length > 0) {
            if (roomResult[0].type === 'public') isMember = true;
            else {
                const [memberResult] = await pool.execute('SELECT 1 FROM room_members WHERE room_id = ? AND user_id = ? AND status = "approved"', [roomId, req.user.id]);
                isMember = memberResult.length > 0;
            }
        }
        if (!isMember) return res.status(403).json({ message: 'Not an approved member of this room.' });
        
        const page = parseInt(req.query.page, 10) || 0;
        const limit = 50;
        const offset = page * limit;

        const sql = `
            SELECT 
                m.id, m.nickname as username, u.display_name as nickname, 
                m.text, m.timestamp, m.image_url, u.avatar_url, m.is_deleted, m.parent_message_id
            FROM messages m 
            LEFT JOIN users u ON m.nickname = u.username 
            LEFT JOIN blocks b ON (b.blocker_id = u.id AND b.blocked_id = ?) OR (b.blocker_id = ? AND b.blocked_id = u.id)
            WHERE m.room_id = ? AND b.id IS NULL
            ORDER BY m.timestamp DESC 
            LIMIT ? OFFSET ?
        `;
        const [rows] = await pool.execute(sql, [currentUserId, currentUserId, roomId, String(limit), String(offset)]);
        
        const messages = rows.map(msg => ({
            ...msg,
            nickname: msg.nickname || 'Deleted User'
        }));

        res.json({ messages: messages, hasNext: rows.length === limit });

    } catch (err) { 
        console.error("Get Messages Error:", err);
        res.status(500).json({ message: 'Failed to load messages.' }); 
    }
});

app.put('/api/messages/:messageId/delete', authenticateToken, async (req, res) => {
    try {
        const { messageId } = req.params;
        const { username } = req.user;

        const [messages] = await pool.execute('SELECT nickname, room_id, image_url FROM messages WHERE id = ?', [messageId]);
        if (messages.length === 0) {
            return res.status(404).json({ message: 'Message not found.' });
        }

        const message = messages[0];
        if (message.nickname !== username) {
            return res.status(403).json({ message: 'You are not authorized to delete this message.' });
        }

        if (message.image_url) {
            const imagePath = path.join(CHAT_IMAGE_PATH, message.image_url);
            if (fs.existsSync(imagePath)) {
                fs.unlink(imagePath, (err) => {
                    if (err) console.error(`Failed to delete chat image ${imagePath}:`, err);
                });
            }
        }

        await pool.execute('UPDATE messages SET is_deleted = 1, text = NULL, image_url = NULL WHERE id = ?', [messageId]);

        io.to(String(message.room_id)).emit('message_deleted', { messageId: messageId, roomId: message.room_id });
        
        res.status(204).send();
    } catch (err) {
        console.error("Delete Message Error:", err);
        res.status(500).json({ message: 'Server error while deleting message.' });
    }
});

// --- Direct Messages & Yêu cầu Tin nhắn API ---

// THAY THẾ TOÀN BỘ route app.post('/api/conversations/start', ...)
app.post('/api/conversations/start', authenticateToken, async (req, res) => {
    const { partnerId } = req.body;
    const currentUserId = req.user.id;

    if (currentUserId == partnerId) {
        return res.status(400).json({ message: "You cannot message yourself." });
    }

    try {
        // --- LOGIC KIỂM TRA BLOCK CHÍNH XÁC ---
        const [[blockStatus]] = await pool.execute('SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)', [currentUserId, partnerId, partnerId, currentUserId]);
        if (blockStatus) {
            return res.status(403).json({ message: "You cannot message this user due to a block." });
        }
        // --- KẾT THÚC LOGIC KIỂM TRA BLOCK ---
        
        const userOneFriend = Math.min(currentUserId, partnerId);
        const userTwoFriend = Math.max(currentUserId, partnerId);
        const [[friendship]] = await pool.execute(
            "SELECT status FROM friends WHERE user_one_id = ? AND user_two_id = ? AND status = 'accepted'",
            [userOneFriend, userTwoFriend]
        );
        const isFriend = friendship;
        
        if (isFriend) {
            const roomName = `dm_${userOneFriend}_${userTwoFriend}`;
            let [[room]] = await pool.execute('SELECT id FROM rooms WHERE name = ? AND type = "direct"', [roomName]);
            if (room) {
                return res.json({ roomId: room.id, isRequest: false });
            }
            const [result] = await pool.execute('INSERT INTO rooms (name, type, creator_id) VALUES (?, "direct", ?)', [roomName, currentUserId]);
            const roomId = result.insertId;
            await pool.execute('INSERT INTO room_members (room_id, user_id, status) VALUES (?, ?, "approved"), (?, ?, "approved")', [roomId, currentUserId, roomId, partnerId]);
            return res.json({ roomId: roomId, isRequest: false });
        }

        const [[recipient]] = await pool.execute('SELECT allow_stranger_messages FROM users WHERE id = ?', [partnerId]);
        if (!recipient || !recipient.allow_stranger_messages) {
            return res.status(403).json({ message: 'This user does not accept messages from non-friends.' });
        }

        const [[existingRequest]] = await pool.execute(
            'SELECT status FROM message_requests WHERE (sender_id = ? AND recipient_id = ?) OR (sender_id = ? AND recipient_id = ?)',
            [currentUserId, partnerId, partnerId, currentUserId]
        );
        if (existingRequest) {
             if(existingRequest.status === 'blocked') return res.status(403).json({ message: 'You are not allowed to message this user.' });
             return res.json({ message: 'A message request is already pending.', isRequest: true });
        }
        
        await pool.execute(
            'INSERT INTO message_requests (sender_id, recipient_id) VALUES (?, ?)',
            [currentUserId, partnerId]
        );
        
        const recipientSocketId = userSockets[partnerId];
        if (recipientSocketId) {
            io.to(recipientSocketId).emit('new_message_request', { 
                sender_id: currentUserId,
                sender_name: req.user.display_name
            });
        }

        res.status(202).json({ message: 'Message request sent.', isRequest: true });

    } catch (err) {
        console.error("Start Conversation Logic Error:", err);
        res.status(500).json({ message: 'Server error.' });
    }
});

app.get('/api/message-requests', authenticateToken, async (req, res) => {
    const currentUserId = req.user.id;
    try {
        const sql = `
            SELECT mr.id, mr.sender_id, u.display_name, u.avatar_url
            FROM message_requests mr
            JOIN users u ON mr.sender_id = u.id
            WHERE mr.recipient_id = ? AND mr.status = 'pending'
            ORDER BY mr.created_at DESC
        `;
        const [requests] = await pool.execute(sql, [currentUserId]);
        res.json(requests);
    } catch (err) {
        res.status(500).json({ message: 'Server error.' });
    }
});

app.post('/api/message-requests/respond', authenticateToken, async (req, res) => {
    const { requestId, action } = req.body; // action: 'accept' or 'decline'
    const currentUserId = req.user.id;
    
    try {
        const [[request]] = await pool.execute(
            'SELECT sender_id FROM message_requests WHERE id = ? AND recipient_id = ?',
            [requestId, currentUserId]
        );
        if (!request) return res.status(404).json({ message: 'Request not found or you are not the recipient.' });

        if (action === 'accept') {
            await pool.execute('UPDATE message_requests SET status = "accepted" WHERE id = ?', [requestId]);
            
            const userOne = Math.min(currentUserId, request.sender_id);
            const userTwo = Math.max(currentUserId, request.sender_id);
            const roomName = `dm_${userOne}_${userTwo}`;
            
            const [result] = await pool.execute('INSERT INTO rooms (name, type, creator_id) VALUES (?, "direct", ?)', [roomName, currentUserId]);
            const roomId = result.insertId;
            await pool.execute('INSERT INTO room_members (room_id, user_id, status) VALUES (?, ?, "approved"), (?, ?, "approved")', [roomId, currentUserId, roomId, request.sender_id]);

            const senderSocketId = userSockets[request.sender_id];
            if(senderSocketId) io.to(senderSocketId).emit('room_list_updated');
            const currentUserSocketId = userSockets[currentUserId];
            if(currentUserSocketId) io.to(currentUserSocketId).emit('room_list_updated');

            return res.json({ message: 'Request accepted.', roomId: roomId });

        } else if (action === 'decline') {
            await pool.execute('DELETE FROM message_requests WHERE id = ?', [requestId]);
            return res.status(204).send();
        } else {
            return res.status(400).json({ message: 'Invalid action.' });
        }
    } catch (err) {
        console.error("Respond Message Request Error:", err);
        res.status(500).json({ message: 'Server error.' });
    }
});


// --- Socket.IO ---
io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    if (!token) return next(new Error('Auth error'));
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return next(new Error('Auth error'));
        socket.user = user;
        next();
    });
});

// THAY THẾ: io.on('connection', ...) để tích hợp trạng thái online và @mention VÀ logic chặn tin nhắn
io.on('connection', (socket) => {
    console.log(`User connected: ${socket.user.username} with id ${socket.id}`);
    userSockets[socket.user.id] = socket.id;

    // Logic trạng thái Online
    if (!onlineUsers.has(socket.user.id)) {
        onlineUsers.add(socket.user.id);
        pool.execute(`SELECT u.id FROM users u JOIN friends f ON (u.id = f.user_one_id OR u.id = f.user_two_id) WHERE (f.user_one_id = ? OR f.user_two_id = ?) AND f.status = 'accepted' AND u.id != ?`, [socket.user.id, socket.user.id, socket.user.id])
        .then(([friends]) => {
            friends.forEach(friend => {
                const friendSocketId = userSockets[friend.id];
                if (friendSocketId) io.to(friendSocketId).emit('friend_online', { userId: socket.user.id });
            });
        }).catch(err => console.error("Error notifying friends of connect:", err));
    }

    socket.on('join room', async (roomId, callback) => {
        try {
            const [room] = await pool.execute('SELECT type FROM rooms WHERE id = ?', [roomId]);
            if (room.length === 0) return callback?.({ success: false, message: 'Room not found.' });
            if (room[0].type === 'public') await pool.execute('INSERT IGNORE INTO room_members (room_id, user_id, role, status) VALUES (?, ?, "member", "approved")', [roomId, socket.user.id]);
            const [members] = await pool.execute('SELECT 1 FROM room_members WHERE room_id = ? AND user_id = ? AND status = "approved"', [roomId, socket.user.id]);
            if (members.length > 0) {
                Array.from(socket.rooms).filter(r => r !== socket.id).forEach(r => socket.leave(r));
                socket.join(String(roomId));
                io.to(String(roomId)).emit('system message', { text: `${socket.user.display_name} has joined.`, roomId });
                callback?.({ success: true });
            } else callback?.({ success: false, message: 'You are not an approved member of this room.' });
        } catch(e) { console.error("Join room error:", e); callback?.({ success: false, message: "Server error." }); }
    });

    // Logic chat message với @mention và trả lời
    socket.on('chat message', async (msg) => {
            const { text, roomId, imageUrl, parent_message_id } = msg;
            if (!socket.rooms.has(String(roomId))) return;
            if ((!text || text.trim() === '') && !imageUrl) return;

            try {
                // MỚI: SỬA LỖI TẠI ĐÂY (Kiểm tra room.length > 0)
                const [roomResult] = await pool.execute('SELECT type FROM rooms WHERE id = ?', [roomId]);
                if (roomResult.length === 0) {
                    // Nếu không tìm thấy phòng, có thể là lỗi client hoặc phòng đã bị xóa
                    socket.emit('system message', { text: 'Lỗi: Phòng chat không tồn tại.', roomId });
                    return;
                }
                const room = roomResult[0]; // Lấy đối tượng phòng

                // KIỂM TRA BLOCK CHẶN TRONG PHÒNG DIRECT MESSAGE
                if (room.type === 'direct') {
                    const [[members]] = await pool.execute('SELECT user_id FROM room_members WHERE room_id = ? AND user_id != ?', [roomId, socket.user.id]);
                    const partnerId = members?.user_id;

                    if (partnerId) {
                        const [[blockStatus]] = await pool.execute(
                            `SELECT 1 FROM blocks WHERE (blocker_id = ? AND blocked_id = ?) OR (blocker_id = ? AND blocked_id = ?)`,
                            [socket.user.id, partnerId, partnerId, socket.user.id]
                        );

                        if (blockStatus) {
                            console.log(`Block detected. User ${socket.user.id} cannot message ${partnerId} in room ${roomId}.`);
                            socket.emit('system message', { text: 'Không thể gửi tin nhắn. Người dùng đã bị chặn hoặc đã chặn bạn.', roomId });
                            return;
                        }
                    }
                }
                // HẾT PHẦN KIỂM TRA BLOCK

                const [result] = await pool.execute('INSERT INTO messages (nickname, text, room_id, image_url, parent_message_id) VALUES (?, ?, ?, ?, ?)', [socket.user.username, text || null, roomId, imageUrl || null, parent_message_id || null]);
                const messageId = result.insertId;
                if (text) {
                    const mentionRegex = /@(\w+)/g;
                    const mentions = text.match(mentionRegex);
                    if (mentions) {
                        const uniqueUsernames = [...new Set(mentions.map(m => m.substring(1)))];
                        for (const username of uniqueUsernames) {
                            const [[mentionedUser]] = await pool.execute('SELECT id FROM users WHERE username = ?', [username]);
                            if (mentionedUser && mentionedUser.id !== socket.user.id) {
                                // Tạo thông báo mention, relatedId là messageId
                                createNotification(mentionedUser.id, socket.user.id, 'mention', messageId);
                            }
                        }
                    }
                }
                io.to(String(roomId)).emit('chat message', { id: messageId, username: socket.user.username, nickname: socket.user.display_name, text, imageUrl, avatar_url: socket.user.avatar_url, timestamp: new Date(), roomId, parent_message_id: parent_message_id, user_id: socket.user.id });
            } catch (err) { console.error('Error saving message:', err); }
        });

    socket.on('typing_start', ({ roomId }) => {
        if (!socket.rooms.has(String(roomId))) return;
        socket.to(String(roomId)).emit('user_typing', { username: socket.user.display_name, roomId });
    });

    socket.on('typing_stop', ({ roomId }) => {
        if (!socket.rooms.has(String(roomId))) return;
        socket.to(String(roomId)).emit('user_stopped_typing', { roomId });
    });

    socket.on('disconnecting', () => {
        Array.from(socket.rooms).filter(r => r !== socket.id).forEach(r => {
            io.to(r).emit('system message', { text: `${socket.user.display_name} has left.`, roomId: r });
        });
    });
    
    // Logic disconnect và trạng thái offline
    socket.on('disconnect', () => {
        const userId = socket.user.id;
        const username = socket.user.username;
        
        // Xóa socket cụ thể này khỏi mapping ngay lập tức.
        if (userSockets[userId] === socket.id) {
            delete userSockets[userId];
        }

        setTimeout(() => {
            // Sau 5s, kiểm tra xem user có còn kết nối nào khác không (ví dụ: refresh trang, tab khác)
            // Nếu không còn socket nào được map với userId này, tức là họ đã offline thực sự
            if (!userSockets[userId]) {
                onlineUsers.delete(userId);
                console.log(`User truly disconnected: ${username}`);
                pool.execute(`SELECT u.id FROM users u JOIN friends f ON (u.id = f.user_one_id OR u.id = f.user_two_id) WHERE (f.user_one_id = ? OR f.user_two_id = ?) AND f.status = 'accepted' AND u.id != ?`, [userId, userId, userId])
                .then(([friends]) => {
                    friends.forEach(friend => {
                        const friendSocketId = userSockets[friend.id];
                        if (friendSocketId) io.to(friendSocketId).emit('friend_offline', { userId: userId });
                    });
                }).catch(err => console.error("Error notifying friends of disconnect:", err));
            }
        }, 5000); // Chờ 5 giây phòng trường hợp user chỉ refresh trang
        console.log(`Socket disconnected: ${username}`);
    });
});

// --- Catch-all Route for SPA ---
app.use((req, res) => {
    if (!req.path.startsWith('/api/') && !req.path.startsWith('/socket.io/')) {
        return res.sendFile(path.join(__dirname, 'public/index.html'));
    }
});

server.listen(PORT, () => console.log(`Server is running at http://localhost:${PORT}`));